import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

function AdminRoute({ children }) {
  const { user, loading, isAdmin } = useAuth()
  
  // If still loading, show nothing
  if (loading) {
    return null
  }
  
  // If not authenticated, redirect to login
  if (!user) {
    return <Navigate to="/login" />
  }
  
  // If not an admin, redirect to dashboard
  if (!isAdmin()) {
    return <Navigate to="/" />
  }
  
  // If authenticated and admin, render the children
  return children
}

export default AdminRoute

"""
Authentication utilities for the NeuraMirror Core MVP.
This module handles user authentication and authorization.
"""

import os
import json
import time
import hashlib
import secrets
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta

# File to store user data
USERS_FILE = "users.json"

# Default admin user
DEFAULT_ADMIN = {
    "username": "admin",
    "password_hash": hashlib.sha256("admin123".encode()).hexdigest(),
    "role": "admin",
    "created_at": datetime.now().isoformat()
}

def init_auth():
    """
    Initialize the authentication system.
    Creates the users file if it doesn't exist and adds a default admin user.
    """
    if not os.path.exists(USERS_FILE):
        with open(USERS_FILE, "w") as f:
            json.dump({"users": [DEFAULT_ADMIN]}, f, indent=2)
        print(f"Created users file with default admin user: {DEFAULT_ADMIN['username']}")

def get_users() -> List[Dict[str, Any]]:
    """
    Get all users from the users file.
    
    Returns:
        List[Dict[str, Any]]: List of user dictionaries
    """
    if not os.path.exists(USERS_FILE):
        init_auth()
    
    with open(USERS_FILE, "r") as f:
        data = json.load(f)
        return data.get("users", [])

def save_users(users: List[Dict[str, Any]]):
    """
    Save users to the users file.
    
    Args:
        users (List[Dict[str, Any]]): List of user dictionaries
    """
    with open(USERS_FILE, "w") as f:
        json.dump({"users": users}, f, indent=2)

def get_user(username: str) -> Optional[Dict[str, Any]]:
    """
    Get a user by username.
    
    Args:
        username (str): Username to look up
        
    Returns:
        Optional[Dict[str, Any]]: User dictionary or None if not found
    """
    users = get_users()
    for user in users:
        if user["username"] == username:
            return user
    return None

def create_user(username: str, password: str, role: str = "user") -> Dict[str, Any]:
    """
    Create a new user.
    
    Args:
        username (str): Username for the new user
        password (str): Password for the new user
        role (str, optional): Role for the new user. Defaults to "user".
        
    Returns:
        Dict[str, Any]: The created user dictionary
    
    Raises:
        ValueError: If the username already exists
    """
    if get_user(username):
        raise ValueError(f"User {username} already exists")
    
    users = get_users()
    
    new_user = {
        "username": username,
        "password_hash": hashlib.sha256(password.encode()).hexdigest(),
        "role": role,
        "created_at": datetime.now().isoformat()
    }
    
    users.append(new_user)
    save_users(users)
    
    return new_user

def verify_password(username: str, password: str) -> bool:
    """
    Verify a user's password.
    
    Args:
        username (str): Username to verify
        password (str): Password to verify
        
    Returns:
        bool: True if the password is correct, False otherwise
    """
    user = get_user(username)
    if not user:
        return False
    
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    return password_hash == user["password_hash"]

def generate_token(username: str) -> str:
    """
    Generate an authentication token for a user.
    
    Args:
        username (str): Username to generate a token for
        
    Returns:
        str: Authentication token
    """
    token = secrets.token_hex(16)
    
    users = get_users()
    for user in users:
        if user["username"] == username:
            user["token"] = token
            user["token_expiry"] = (datetime.now() + timedelta(hours=24)).isoformat()
            break
    
    save_users(users)
    
    return token

def verify_token(token: str) -> Optional[Dict[str, Any]]:
    """
    Verify an authentication token.
    
    Args:
        token (str): Token to verify
        
    Returns:
        Optional[Dict[str, Any]]: User dictionary if the token is valid, None otherwise
    """
    users = get_users()
    for user in users:
        if user.get("token") == token:
            # Check if token has expired
            expiry = datetime.fromisoformat(user.get("token_expiry", "2000-01-01T00:00:00"))
            if expiry > datetime.now():
                return user
    
    return None

def invalidate_token(token: str) -> bool:
    """
    Invalidate an authentication token.
    
    Args:
        token (str): Token to invalidate
        
    Returns:
        bool: True if the token was invalidated, False otherwise
    """
    users = get_users()
    for user in users:
        if user.get("token") == token:
            user.pop("token", None)
            user.pop("token_expiry", None)
            save_users(users)
            return True
    
    return False

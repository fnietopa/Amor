import { useState, useEffect } from 'react'
import { Routes, Route, Link, Navigate } from 'react-router-dom'
import styled from 'styled-components'
import { FaBrain, FaChartBar, FaExclamationTriangle, FaHistory, FaHome, FaSignOutAlt, FaUserShield } from 'react-icons/fa'
import api from './utils/api'

// Context
import { AuthProvider, useAuth } from './context/AuthContext'

// Components
import Header from './components/Header'
import Dashboard from './components/Dashboard'
import QuestionForm from './components/QuestionForm'
import QuestionDetails from './components/QuestionDetails'
import ModelList from './components/ModelList'
import ErrorFlags from './components/ErrorFlags'
import History from './components/History'
import Login from './components/Login'
import ProtectedRoute from './components/ProtectedRoute'
import AdminRoute from './components/AdminRoute'
import Admin from './components/Admin'

// Styled components
const AppContainer = styled.div`
  display: flex;
  min-height: 100vh;
`

const Sidebar = styled.div`
  width: 250px;
  background-color: #2c3e50;
  color: white;
  padding: 20px 0;
`

const SidebarLink = styled(Link)`
  display: flex;
  align-items: center;
  padding: 10px 20px;
  color: white;
  text-decoration: none;
  transition: background-color 0.3s;

  &:hover {
    background-color: #34495e;
  }

  &.active {
    background-color: #3498db;
  }

  svg {
    margin-right: 10px;
  }
`

const MainContent = styled.div`
  flex: 1;
  padding: 20px;
  background-color: #f8f9fa;
`

// Main App component with authentication
function AppContent() {
  const { user, logout, isAdmin } = useAuth()
  const [models, setModels] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Fetch models when the app loads
    const fetchModels = async () => {
      try {
        const response = await api.get('/models')
        setModels(response.data)
      } catch (error) {
        console.error('Error fetching models:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchModels()
  }, [])

  // If not authenticated, show login page
  if (!user) {
    return <Login onLogin={(userData) => console.log('Logged in:', userData)} />
  }

  return (
    <AppContainer>
      <Sidebar>
        <div style={{ padding: '20px', textAlign: 'center', marginBottom: '20px' }}>
          <h2>NeuraMirror</h2>
          <p>Core MVP</p>
        </div>
        <nav>
          <SidebarLink to="/">
            <FaHome /> Home
          </SidebarLink>
          <SidebarLink to="/models">
            <FaBrain /> Models
          </SidebarLink>
          <SidebarLink to="/history">
            <FaHistory /> History
          </SidebarLink>
          <SidebarLink to="/errors">
            <FaExclamationTriangle /> Errors
          </SidebarLink>
          <SidebarLink to="/stats">
            <FaChartBar /> Statistics
          </SidebarLink>

          {isAdmin() && (
            <SidebarLink to="/admin">
              <FaUserShield /> Admin
            </SidebarLink>
          )}

          <SidebarLink as="button" onClick={logout} style={{ width: '100%', textAlign: 'left' }}>
            <FaSignOutAlt /> Logout
          </SidebarLink>
        </nav>
      </Sidebar>

      <MainContent>
        <Header />

        <Routes>
          <Route path="/" element={<Dashboard models={models} loading={loading} />} />
          <Route path="/question" element={<QuestionForm models={models} />} />
          <Route path="/question/:id" element={<QuestionDetails />} />
          <Route path="/models" element={<ModelList models={models} loading={loading} />} />
          <Route path="/errors" element={<ErrorFlags />} />
          <Route path="/history" element={<History />} />
          <Route path="/stats" element={<div>Statistics page (coming soon)</div>} />
          <Route path="/admin" element={isAdmin() ? <Admin /> : <Navigate to="/" />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </MainContent>
    </AppContainer>
  )
}

// Wrap the app with AuthProvider
function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  )
}

export default App

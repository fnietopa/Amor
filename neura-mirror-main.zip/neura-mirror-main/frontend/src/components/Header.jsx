import { Link } from 'react-router-dom'
import styled from 'styled-components'

const HeaderContainer = styled.header`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 0 20px 0;
  margin-bottom: 20px;
  border-bottom: 1px solid var(--border-color);
`

const Title = styled.h1`
  font-size: 1.5rem;
  color: var(--text-color);
`

const ActionButton = styled(Link)`
  display: inline-block;
  padding: 10px 15px;
  background-color: var(--primary-color);
  color: white;
  text-decoration: none;
  border-radius: 4px;
  transition: background-color 0.3s;
  
  &:hover {
    background-color: #2980b9;
  }
`

function Header() {
  return (
    <HeaderContainer>
      <Title>NeuraMirror Core MVP</Title>
      <ActionButton to="/question">Ask a Question</ActionButton>
    </HeaderContainer>
  )
}

export default Header

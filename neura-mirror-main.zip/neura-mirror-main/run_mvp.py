"""
Main script to run the NeuraMirror Core MVP.
This script orchestrates the entire process of model discovery, question distribution,
evaluation, error handling, expertise testing, and model self-testing.
"""

import asyncio
import json
import time
from typing import Dict, List, Any, Tuple, Optional

import ollama_utils
import eval_utils
import error_utils
import test_utils
import db_module

# Initialize the database
db_module.init_db()

# Initialize the evaluator
evaluator = eval_utils.ResponseEvaluator()

async def process_question(question: str, models: List[str] = None, params: Dict[str, Any] = None):
    """
    Process a question through the entire NeuraMirror pipeline.
    
    Args:
        question (str): The question to process
        models (List[str], optional): List of model names to use. Defaults to None.
        params (Dict[str, Any], optional): Parameters for the models. Defaults to None.
    """
    if params is None:
        params = {
            "num_predict": 1024,
            "temperature": 0.7,
            "top_k": 40,
            "top_p": 0.9,
            "repeat_penalty": 1.1,
            "stop": []
        }
    
    # Save the question to the database
    question_id = db_module.save_question(question)
    
    print(f"Processing question: {question}")
    print(f"Question ID: {question_id}")
    
    # If no models are specified, get all available models
    if models is None:
        models_info = ollama_utils.list_models_api()
        models = [model["name"] for model in models_info]
    
    print(f"Using models: {', '.join(models)}")
    
    # Stage 1: Round-Robin Question Distribution
    attempts = 0
    success = False
    current_params = params.copy()
    
    while attempts < error_utils.MAX_ATTEMPTS and not success:
        attempts += 1
        print(f"\nAttempt {attempts} with parameters: {current_params}")
        
        # Query all models
        responses = await ollama_utils.query_all_models(question, models, current_params, timeout=120)
        
        # Save responses to the database
        for model_name, response_data in responses.items():
            db_module.save_response(question_id, model_name, response_data, attempts, current_params)
        
        # Check for errors
        error_models = []
        for model_name, response_data in responses.items():
            has_error, error_message = error_utils.detect_errors(response_data)
            if has_error:
                print(f"Error in model {model_name}: {error_message}")
                error_models.append((model_name, error_message))
                db_module.save_error_flag(model_name, error_message, attempts, attempts >= error_utils.MAX_ATTEMPTS)
        
        # If all models have errors, adjust parameters and retry
        if len(error_models) == len(models):
            print("All models encountered errors. Adjusting parameters and retrying...")
            current_params = error_utils.adjust_params(current_params, attempts, error_models[0][1])
            continue
        
        # Stage 2: Evaluation and Automatic Selection
        scores = evaluator.evaluate_responses(responses)
        
        # Save scores to the database
        for model_name, model_scores in scores.items():
            db_module.save_scores(question_id, model_name, model_scores)
        
        # Select the best model
        best_model, best_score = evaluator.select_best_model(scores)
        
        # Check if the best score is sufficient
        if not error_utils.is_quality_sufficient(best_score):
            print(f"Best score ({best_score}) is below threshold. Adjusting parameters and retrying...")
            current_params = error_utils.adjust_params(current_params, attempts)
            continue
        
        # If we get here, we have a successful run
        success = True
        
        # Save the best model to the database
        db_module.save_best_model(question_id, best_model, best_score)
        
        print(f"\nBest model: {best_model} with score: {best_score}")
        print(f"Response: {responses[best_model]['response'][:200]}...")
    
    if not success:
        print(f"Failed to get satisfactory responses after {attempts} attempts.")
        return
    
    # Stage 3: Expertise Assessment
    print("\nStage 3: Expertise Assessment")
    expertise_info = ollama_utils.query_model_for_expertise(best_model, current_params)
    
    # Save expertise to the database
    db_module.save_expertise(best_model, expertise_info)
    
    print(f"Expertise areas for {best_model}:")
    for area, languages in expertise_info.items():
        print(f"  {area}: {', '.join(languages)}")
    
    # Stage 4: Expertise Testing
    print("\nStage 4: Expertise Testing")
    for field, languages in expertise_info.items():
        for language in languages:
            print(f"\nTesting {best_model} on {field} in {language}")
            
            # Generate reference criteria for evaluation
            reference_criteria = test_utils.generate_reference_criteria(field, language)
            
            # Have other models generate questions for this field and language
            for model in models:
                if model == best_model:
                    continue
                
                # Generate a question
                question = test_utils.generate_question_for_field_language(field, language, model, current_params)
                print(f"Question from {model}: {question}")
                
                # Get a response from the best model
                response, _ = ollama_utils.query_model(best_model, question, current_params)
                print(f"Response from {best_model} (truncated): {response[:200]}...")
                
                # Evaluate the response
                scores = test_utils.evaluate_field_response(response, reference_criteria)
                print(f"Scores: {scores}")
                
                # Save the field test to the database
                db_module.save_field_test(best_model, field, language, question, response, scores)
    
    # Stage 5: Model Self-Testing
    print("\nStage 5: Model Self-Testing")
    test_categories = ["genel", "custom", "stratejik"]
    test_scores = {}
    
    for test_category in test_categories:
        print(f"\nRunning {test_category} tests")
        
        for model in models:
            # Generate a test question
            test_question = test_utils.generate_test_question(model, test_category, current_params)
            print(f"Question from {model} for {test_category} test: {test_question}")
            
            # Get a response from the model
            test_response, _ = ollama_utils.query_model(model, test_question, current_params)
            print(f"Response from {model} (truncated): {test_response[:200]}...")
            
            # Evaluate the response
            test_score = evaluator.evaluate_test_response(test_response, test_category)
            print(f"Score for {model} on {test_category} test: {test_score}")
            
            # Save the model test to the database
            db_module.save_model_test(model, test_category, test_question, test_response, test_score)
            
            # Store the score for overall calculation
            test_scores.setdefault(model, []).append(test_score)
    
    # Calculate overall test scores
    overall_test_scores = {model: sum(scores) / len(scores) for model, scores in test_scores.items()}
    
    print("\nOverall test scores:")
    for model, score in overall_test_scores.items():
        print(f"  {model}: {score}")
    
    print("\nProcessing complete!")

async def main():
    """
    Main function to run the NeuraMirror Core MVP.
    """
    # Check if Ollama is available
    models = ollama_utils.list_models_api()
    if not models:
        print("Error: Could not connect to Ollama API. Make sure Ollama is running.")
        return
    
    print(f"Found {len(models)} models: {', '.join([model['name'] for model in models])}")
    
    # Sample questions for testing
    questions = [
        "What are the key differences between supervised and unsupervised learning in machine learning?",
        "Explain the concept of quantum entanglement in simple terms.",
        "What are the major economic impacts of climate change?",
        "How does the human immune system respond to viral infections?",
        "What are the ethical considerations in artificial intelligence development?"
    ]
    
    # Process each question
    for question in questions:
        await process_question(question)
        print("\n" + "="*80 + "\n")

if __name__ == "__main__":
    asyncio.run(main())

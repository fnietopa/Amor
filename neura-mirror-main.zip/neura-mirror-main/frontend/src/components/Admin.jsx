import { useState } from 'react'
import styled from 'styled-components'
import { FaDownload, FaUpload, FaUserPlus, FaUsers } from 'react-icons/fa'
import { useAuth } from '../context/AuthContext'

const AdminContainer = styled.div`
  padding: 20px;
`

const AdminCard = styled.div`
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-bottom: 20px;
`

const AdminHeader = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 20px;
  
  svg {
    margin-right: 10px;
    color: var(--primary-color);
  }
`

const AdminTitle = styled.h2`
  margin: 0;
  font-size: 1.5rem;
`

const AdminForm = styled.form`
  display: flex;
  flex-direction: column;
`

const FormGroup = styled.div`
  margin-bottom: 15px;
`

const Label = styled.label`
  display: block;
  margin-bottom: 5px;
  font-weight: 500;
`

const Input = styled.input`
  width: 100%;
  padding: 10px;
  border: 1px solid var(--border-color);
  border-radius: 4px;
  font-size: 1rem;
`

const Select = styled.select`
  width: 100%;
  padding: 10px;
  border: 1px solid var(--border-color);
  border-radius: 4px;
  font-size: 1rem;
`

const Button = styled.button`
  padding: 10px 15px;
  background-color: var(--primary-color);
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 1rem;
  cursor: pointer;
  transition: background-color 0.3s;
  display: flex;
  align-items: center;
  justify-content: center;
  
  svg {
    margin-right: 8px;
  }
  
  &:hover {
    background-color: #2980b9;
  }
  
  &:disabled {
    background-color: #95a5a6;
    cursor: not-allowed;
  }
`

const ButtonGroup = styled.div`
  display: flex;
  gap: 10px;
`

const SuccessMessage = styled.div`
  color: var(--success-color);
  margin-top: 10px;
  padding: 10px;
  background-color: #d4edda;
  border-radius: 4px;
`

const ErrorMessage = styled.div`
  color: var(--error-color);
  margin-top: 10px;
  padding: 10px;
  background-color: #f8d7da;
  border-radius: 4px;
`

function Admin() {
  const { getToken } = useAuth()
  
  const [newUser, setNewUser] = useState({
    username: '',
    password: '',
    role: 'user'
  })
  
  const [importPath, setImportPath] = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState('')
  const [error, setError] = useState('')
  
  const handleCreateUser = async (e) => {
    e.preventDefault()
    
    if (!newUser.username || !newUser.password) {
      setError('Please enter both username and password')
      return
    }
    
    setLoading(true)
    setError('')
    setSuccess('')
    
    try {
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getToken()}`
        },
        body: JSON.stringify(newUser)
      })
      
      if (response.ok) {
        setSuccess(`User ${newUser.username} created successfully`)
        setNewUser({
          username: '',
          password: '',
          role: 'user'
        })
      } else {
        const errorData = await response.json()
        throw new Error(errorData.detail || 'Failed to create user')
      }
    } catch (error) {
      setError(error.message || 'An error occurred')
    } finally {
      setLoading(false)
    }
  }
  
  const handleExportData = async () => {
    setLoading(true)
    setError('')
    setSuccess('')
    
    try {
      const response = await fetch('/api/export', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${getToken()}`
        }
      })
      
      if (response.ok) {
        const data = await response.json()
        setSuccess(`Data exported successfully to ${data.file_path}`)
      } else {
        const errorData = await response.json()
        throw new Error(errorData.detail || 'Failed to export data')
      }
    } catch (error) {
      setError(error.message || 'An error occurred')
    } finally {
      setLoading(false)
    }
  }
  
  const handleImportData = async (e) => {
    e.preventDefault()
    
    if (!importPath) {
      setError('Please enter an import file path')
      return
    }
    
    setLoading(true)
    setError('')
    setSuccess('')
    
    try {
      const response = await fetch('/api/import', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getToken()}`
        },
        body: JSON.stringify({ import_path: importPath })
      })
      
      if (response.ok) {
        const data = await response.json()
        setSuccess(data.message || 'Data imported successfully')
        setImportPath('')
      } else {
        const errorData = await response.json()
        throw new Error(errorData.detail || 'Failed to import data')
      }
    } catch (error) {
      setError(error.message || 'An error occurred')
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <AdminContainer>
      <h1>Admin Dashboard</h1>
      
      <AdminCard>
        <AdminHeader>
          <FaUsers />
          <AdminTitle>User Management</AdminTitle>
        </AdminHeader>
        
        <AdminForm onSubmit={handleCreateUser}>
          <FormGroup>
            <Label htmlFor="username">Username</Label>
            <Input
              id="username"
              type="text"
              value={newUser.username}
              onChange={(e) => setNewUser({ ...newUser, username: e.target.value })}
              disabled={loading}
            />
          </FormGroup>
          
          <FormGroup>
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={newUser.password}
              onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
              disabled={loading}
            />
          </FormGroup>
          
          <FormGroup>
            <Label htmlFor="role">Role</Label>
            <Select
              id="role"
              value={newUser.role}
              onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
              disabled={loading}
            >
              <option value="user">User</option>
              <option value="admin">Admin</option>
            </Select>
          </FormGroup>
          
          <Button type="submit" disabled={loading}>
            <FaUserPlus />
            Create User
          </Button>
        </AdminForm>
      </AdminCard>
      
      <AdminCard>
        <AdminHeader>
          <FaDownload />
          <AdminTitle>Data Export/Import</AdminTitle>
        </AdminHeader>
        
        <ButtonGroup>
          <Button onClick={handleExportData} disabled={loading}>
            <FaDownload />
            Export Data
          </Button>
        </ButtonGroup>
        
        <AdminForm onSubmit={handleImportData} style={{ marginTop: '20px' }}>
          <FormGroup>
            <Label htmlFor="importPath">Import File Path</Label>
            <Input
              id="importPath"
              type="text"
              value={importPath}
              onChange={(e) => setImportPath(e.target.value)}
              placeholder="/path/to/neuramirror_export.zip"
              disabled={loading}
            />
          </FormGroup>
          
          <Button type="submit" disabled={loading}>
            <FaUpload />
            Import Data
          </Button>
        </AdminForm>
      </AdminCard>
      
      {success && <SuccessMessage>{success}</SuccessMessage>}
      {error && <ErrorMessage>{error}</ErrorMessage>}
    </AdminContainer>
  )
}

export default Admin

# NeuraMirror Core MVP

NeuraMirror Core MVP is an intelligent system that enables interaction with multiple local Ollama models, distributing questions in a round-robin fashion, evaluating responses, and determining the most competent model through a series of tests.

## Features

- Automatic discovery and integration with local Ollama models
- Round-robin question distribution and asynchronous response collection
- Mutual evaluation and automatic selection of the best model
- Expertise assessment for domain and language proficiency
- Self-testing capabilities (general, custom, and strategic tests)
- Autonomous error detection and self-improvement
- Modern web interface for monitoring and interaction

## Prerequisites

- Python 3.8+
- Node.js 16+
- Ollama installed and running with at least one model
- npm or yarn

## Installation

### Backend Setup

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/neuramirror.git
   cd neuramirror
   ```

2. Create a virtual environment and activate it:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install the required Python packages:
   ```
   pip install -r requirements.txt
   ```

### Frontend Setup

1. Navigate to the frontend directory:
   ```
   cd frontend
   ```

2. Install the required npm packages:
   ```
   npm install
   ```

## Running the Application

### Start the Backend

1. Make sure Ollama is running with at least one model installed.

2. Start the FastAPI backend:
   ```
   uvicorn api:app --reload
   ```

   The API will be available at http://localhost:8000.

### Start the Frontend

1. In a separate terminal, navigate to the frontend directory:
   ```
   cd frontend
   ```

2. Start the development server:
   ```
   npm run dev
   ```

   The frontend will be available at http://localhost:5173.

## Usage

1. Open your browser and navigate to http://localhost:5173.

2. Use the "Ask a Question" button to submit a question to the system.

3. The system will distribute the question to all available Ollama models, evaluate their responses, and select the best model.

4. View the results, including model responses, evaluation scores, and expertise assessments.

## Project Structure

- `ollama_utils.py`: Utilities for interacting with Ollama models
- `eval_utils.py`: Evaluation metrics and functions
- `error_utils.py`: Error handling and parameter adjustment
- `test_utils.py`: Test generation and evaluation
- `db_module.py`: Database operations
- `run_mvp.py`: Main script for running the application
- `api.py`: FastAPI backend
- `frontend/`: React frontend

## License

This project is licensed under the MIT License - see the LICENSE file for details.

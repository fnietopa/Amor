"""
Utility functions for error handling and parameter adjustment.
This module handles timeout detection, empty response detection, and parameter adjustment.
"""

from typing import Dict, Any, Tuple, Optional

# Constants for quality thresholds
QUALITY_THRESHOLD = 0.5  # Minimum acceptable quality score
MAX_ATTEMPTS = 3  # Maximum number of retry attempts

def detect_errors(response_data: Dict[str, Any]) -> Tuple[bool, str]:
    """
    Detect errors in a model response.
    
    Args:
        response_data (Dict[str, Any]): Response data from a model
        
    Returns:
        Tuple[bool, str]: Tuple of (has_error, error_message)
    """
    status = response_data.get("status", "")
    response = response_data.get("response", "")
    
    if status == "timeout":
        return True, "Timeout error"
    
    if status == "error":
        return True, f"API error: {response}"
    
    if not response.strip():
        return True, "Empty response"
    
    return False, ""

def adjust_params(params: Dict[str, Any], attempt: int, error_type: str = None) -> Dict[str, Any]:
    """
    Adjust parameters based on the error type and attempt number.
    
    Args:
        params (Dict[str, Any]): Current parameters
        attempt (int): Current attempt number
        error_type (str, optional): Type of error encountered. Defaults to None.
        
    Returns:
        Dict[str, Any]: Adjusted parameters
    """
    # Make a copy of the parameters to avoid modifying the original
    adjusted_params = params.copy()
    
    # Default adjustments based on attempt number
    if attempt == 1:
        # First retry: Increase token limit and slightly adjust temperature
        adjusted_params["num_predict"] = min(adjusted_params.get("num_predict", 1024) * 1.5, 4096)
        adjusted_params["temperature"] = max(adjusted_params.get("temperature", 0.7) - 0.1, 0.1)
    elif attempt == 2:
        # Second retry: Further increase token limit and adjust other parameters
        adjusted_params["num_predict"] = min(adjusted_params.get("num_predict", 1024) * 2, 8192)
        adjusted_params["temperature"] = min(adjusted_params.get("temperature", 0.7) + 0.2, 1.0)
        adjusted_params["top_p"] = min(adjusted_params.get("top_p", 0.9) + 0.05, 1.0)
    
    # Specific adjustments based on error type
    if error_type == "Timeout error":
        # For timeouts, reduce complexity to get faster responses
        adjusted_params["num_predict"] = min(adjusted_params.get("num_predict", 1024), 2048)
        adjusted_params["temperature"] = max(adjusted_params.get("temperature", 0.7) - 0.2, 0.1)
    elif error_type == "Empty response":
        # For empty responses, increase creativity
        adjusted_params["temperature"] = min(adjusted_params.get("temperature", 0.7) + 0.3, 1.0)
        adjusted_params["top_p"] = min(adjusted_params.get("top_p", 0.9) + 0.1, 1.0)
        adjusted_params["repeat_penalty"] = max(adjusted_params.get("repeat_penalty", 1.1) - 0.1, 1.0)
    
    return adjusted_params

def is_quality_sufficient(score: float) -> bool:
    """
    Check if a quality score is sufficient.
    
    Args:
        score (float): Quality score to check
        
    Returns:
        bool: True if the score is sufficient, False otherwise
    """
    return score >= QUALITY_THRESHOLD

def should_retry(attempt: int) -> bool:
    """
    Check if another retry attempt should be made.
    
    Args:
        attempt (int): Current attempt number
        
    Returns:
        bool: True if another retry should be made, False otherwise
    """
    return attempt < MAX_ATTEMPTS

def create_error_flag(model: str, error_type: str, attempt: int) -> Dict[str, Any]:
    """
    Create an error flag for manual review.
    
    Args:
        model (str): Name of the model that encountered the error
        error_type (str): Type of error encountered
        attempt (int): Attempt number when the error occurred
        
    Returns:
        Dict[str, Any]: Error flag data
    """
    return {
        "model": model,
        "error_type": error_type,
        "attempt": attempt,
        "requires_manual_review": True,
        "timestamp": None  # In a real implementation, you would add a timestamp here
    }

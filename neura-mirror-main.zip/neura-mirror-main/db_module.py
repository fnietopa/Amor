"""
Database module for storing and retrieving data.
This module handles database operations for the NeuraMirror Core MVP.
"""

import sqlite3
import json
import os
import time
from typing import Dict, List, Any, Tuple, Optional
from datetime import datetime

# Database file path
DB_FILE = "neuramirror.db"

def init_db():
    """
    Initialize the database with the necessary tables.
    """
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    # Create tables if they don't exist

    # Questions table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        text TEXT NOT NULL,
        timestamp TEXT NOT NULL
    )
    ''')

    # Responses table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS responses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question_id INTEGER NOT NULL,
        model_name TEXT NOT NULL,
        response_text TEXT NOT NULL,
        elapsed_time REAL NOT NULL,
        status TEXT NOT NULL,
        attempt INTEGER NOT NULL,
        params TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        FOREIGN KEY (question_id) REFERENCES questions (id)
    )
    ''')

    # Scores table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS scores (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question_id INTEGER NOT NULL,
        model_name TEXT NOT NULL,
        jaccard_similarity REAL NOT NULL,
        dice_coefficient REAL NOT NULL,
        overlap_coefficient REAL NOT NULL,
        length_ratio REAL NOT NULL,
        overall_score REAL NOT NULL,
        timestamp TEXT NOT NULL,
        FOREIGN KEY (question_id) REFERENCES questions (id)
    )
    ''')

    # Best models table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS best_models (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question_id INTEGER NOT NULL,
        model_name TEXT NOT NULL,
        score REAL NOT NULL,
        timestamp TEXT NOT NULL,
        FOREIGN KEY (question_id) REFERENCES questions (id)
    )
    ''')

    # Expertise table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS expertise (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        model_name TEXT NOT NULL,
        expertise_data TEXT NOT NULL,
        timestamp TEXT NOT NULL
    )
    ''')

    # Field tests table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS field_tests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        model_name TEXT NOT NULL,
        field TEXT NOT NULL,
        language TEXT NOT NULL,
        question TEXT NOT NULL,
        response TEXT NOT NULL,
        scores TEXT NOT NULL,
        timestamp TEXT NOT NULL
    )
    ''')

    # Model tests table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS model_tests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        model_name TEXT NOT NULL,
        test_category TEXT NOT NULL,
        question TEXT NOT NULL,
        response TEXT NOT NULL,
        score REAL NOT NULL,
        timestamp TEXT NOT NULL
    )
    ''')

    # Error flags table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS error_flags (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        model_name TEXT NOT NULL,
        error_type TEXT NOT NULL,
        attempt INTEGER NOT NULL,
        requires_manual_review INTEGER NOT NULL,
        timestamp TEXT NOT NULL
    )
    ''')

    conn.commit()
    conn.close()

def save_question(question: str) -> int:
    """
    Save a question to the database.

    Args:
        question (str): The question text

    Returns:
        int: The ID of the saved question
    """
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    timestamp = datetime.now().isoformat()
    cursor.execute(
        "INSERT INTO questions (text, timestamp) VALUES (?, ?)",
        (question, timestamp)
    )

    question_id = cursor.lastrowid

    conn.commit()
    conn.close()

    return question_id

def save_response(question_id: int, model_name: str, response_data: Dict[str, Any], attempt: int, params: Dict[str, Any]):
    """
    Save a model's response to the database.

    Args:
        question_id (int): The ID of the question
        model_name (str): The name of the model
        response_data (Dict[str, Any]): The response data
        attempt (int): The attempt number
        params (Dict[str, Any]): The parameters used for the query
    """
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    timestamp = datetime.now().isoformat()
    cursor.execute(
        "INSERT INTO responses (question_id, model_name, response_text, elapsed_time, status, attempt, params, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (
            question_id,
            model_name,
            response_data.get("response", ""),
            response_data.get("elapsed_time", 0.0),
            response_data.get("status", "unknown"),
            attempt,
            json.dumps(params),
            timestamp
        )
    )

    conn.commit()
    conn.close()

def save_scores(question_id: int, model_name: str, scores: Dict[str, float]):
    """
    Save evaluation scores to the database.

    Args:
        question_id (int): The ID of the question
        model_name (str): The name of the model
        scores (Dict[str, float]): The evaluation scores
    """
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    timestamp = datetime.now().isoformat()
    cursor.execute(
        "INSERT INTO scores (question_id, model_name, jaccard_similarity, dice_coefficient, overlap_coefficient, length_ratio, overall_score, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (
            question_id,
            model_name,
            scores.get("jaccard_similarity", 0.0),
            scores.get("dice_coefficient", 0.0),
            scores.get("overlap_coefficient", 0.0),
            scores.get("length_ratio", 0.0),
            scores.get("overall_score", 0.0),
            timestamp
        )
    )

    conn.commit()
    conn.close()

def save_best_model(question_id: int, model_name: str, score: float):
    """
    Save the best model for a question to the database.

    Args:
        question_id (int): The ID of the question
        model_name (str): The name of the best model
        score (float): The overall score of the best model
    """
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    timestamp = datetime.now().isoformat()
    cursor.execute(
        "INSERT INTO best_models (question_id, model_name, score, timestamp) VALUES (?, ?, ?, ?)",
        (question_id, model_name, score, timestamp)
    )

    conn.commit()
    conn.close()

def save_expertise(model_name: str, expertise_data: Dict[str, List[str]]):
    """
    Save a model's expertise data to the database.

    Args:
        model_name (str): The name of the model
        expertise_data (Dict[str, List[str]]): The expertise data
    """
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    timestamp = datetime.now().isoformat()
    cursor.execute(
        "INSERT INTO expertise (model_name, expertise_data, timestamp) VALUES (?, ?, ?)",
        (model_name, json.dumps(expertise_data), timestamp)
    )

    conn.commit()
    conn.close()

def save_field_test(model_name: str, field: str, language: str, question: str, response: str, scores: Dict[str, float]):
    """
    Save a field test to the database.

    Args:
        model_name (str): The name of the model
        field (str): The expertise field
        language (str): The language of the question
        question (str): The question text
        response (str): The model's response
        scores (Dict[str, float]): The evaluation scores
    """
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    timestamp = datetime.now().isoformat()
    cursor.execute(
        "INSERT INTO field_tests (model_name, field, language, question, response, scores, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (model_name, field, language, question, response, json.dumps(scores), timestamp)
    )

    conn.commit()
    conn.close()

def save_model_test(model_name: str, test_category: str, question: str, response: str, score: float):
    """
    Save a model test to the database.

    Args:
        model_name (str): The name of the model
        test_category (str): The category of the test
        question (str): The question text
        response (str): The model's response
        score (float): The evaluation score
    """
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    timestamp = datetime.now().isoformat()
    cursor.execute(
        "INSERT INTO model_tests (model_name, test_category, question, response, score, timestamp) VALUES (?, ?, ?, ?, ?, ?)",
        (model_name, test_category, question, response, score, timestamp)
    )

    conn.commit()
    conn.close()

def save_error_flag(model_name: str, error_type: str, attempt: int, requires_manual_review: bool):
    """
    Save an error flag to the database.

    Args:
        model_name (str): The name of the model
        error_type (str): The type of error
        attempt (int): The attempt number
        requires_manual_review (bool): Whether manual review is required
    """
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    timestamp = datetime.now().isoformat()
    cursor.execute(
        "INSERT INTO error_flags (model_name, error_type, attempt, requires_manual_review, timestamp) VALUES (?, ?, ?, ?, ?)",
        (model_name, error_type, attempt, 1 if requires_manual_review else 0, timestamp)
    )

    conn.commit()
    conn.close()

def get_question(question_id: int) -> Optional[Dict[str, Any]]:
    """
    Get a question from the database.

    Args:
        question_id (int): The ID of the question

    Returns:
        Optional[Dict[str, Any]]: The question data, or None if not found
    """
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM questions WHERE id = ?", (question_id,))
    row = cursor.fetchone()

    conn.close()

    if row:
        return dict(row)
    else:
        return None

def get_responses(question_id: int) -> List[Dict[str, Any]]:
    """
    Get all responses for a question from the database.

    Args:
        question_id (int): The ID of the question

    Returns:
        List[Dict[str, Any]]: List of response data
    """
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM responses WHERE question_id = ?", (question_id,))
    rows = cursor.fetchall()

    conn.close()

    return [dict(row) for row in rows]

def get_best_model(question_id: int) -> Optional[Dict[str, Any]]:
    """
    Get the best model for a question from the database.

    Args:
        question_id (int): The ID of the question

    Returns:
        Optional[Dict[str, Any]]: The best model data, or None if not found
    """
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM best_models WHERE question_id = ?", (question_id,))
    row = cursor.fetchone()

    conn.close()

    if row:
        return dict(row)
    else:
        return None

def get_expertise(model_name: str) -> Optional[Dict[str, List[str]]]:
    """
    Get a model's expertise data from the database.

    Args:
        model_name (str): The name of the model

    Returns:
        Optional[Dict[str, List[str]]]: The expertise data, or None if not found
    """
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    cursor.execute("SELECT expertise_data FROM expertise WHERE model_name = ? ORDER BY timestamp DESC LIMIT 1", (model_name,))
    row = cursor.fetchone()

    conn.close()

    if row:
        return json.loads(row[0])
    else:
        return None

def get_field_tests(model_name: str) -> List[Dict[str, Any]]:
    """
    Get all field tests for a model from the database.

    Args:
        model_name (str): The name of the model

    Returns:
        List[Dict[str, Any]]: List of field test data
    """
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM field_tests WHERE model_name = ?", (model_name,))
    rows = cursor.fetchall()

    conn.close()

    return [dict(row) for row in rows]

def get_model_tests(model_name: str) -> List[Dict[str, Any]]:
    """
    Get all model tests for a model from the database.

    Args:
        model_name (str): The name of the model

    Returns:
        List[Dict[str, Any]]: List of model test data
    """
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM model_tests WHERE model_name = ?", (model_name,))
    rows = cursor.fetchall()

    conn.close()

    return [dict(row) for row in rows]

def get_error_flags(model_name: str = None) -> List[Dict[str, Any]]:
    """
    Get all error flags from the database.

    Args:
        model_name (str, optional): The name of the model. Defaults to None.

    Returns:
        List[Dict[str, Any]]: List of error flag data
    """
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    if model_name:
        cursor.execute("SELECT * FROM error_flags WHERE model_name = ?", (model_name,))
    else:
        cursor.execute("SELECT * FROM error_flags")

    rows = cursor.fetchall()

    conn.close()

    return [dict(row) for row in rows]

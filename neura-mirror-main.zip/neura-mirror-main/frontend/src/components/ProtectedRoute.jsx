import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth()
  
  // If still loading, show nothing
  if (loading) {
    return null
  }
  
  // If not authenticated, redirect to login
  if (!user) {
    return <Navigate to="/login" />
  }
  
  // If authenticated, render the children
  return children
}

export default ProtectedRoute

import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import styled from 'styled-components'
import { FaSpinner } from 'react-icons/fa'

const DashboardContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
  margin-bottom: 30px;
`

const DashboardCard = styled.div`
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  padding: 20px;
  display: flex;
  flex-direction: column;
`

const CardTitle = styled.h2`
  font-size: 1.2rem;
  margin-bottom: 15px;
  color: var(--text-color);
`

const CardValue = styled.div`
  font-size: 2rem;
  font-weight: bold;
  margin-bottom: 10px;
  color: var(--primary-color);
`

const RecentQuestionsContainer = styled.div`
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-top: 20px;
`

const QuestionItem = styled.div`
  padding: 15px 0;
  border-bottom: 1px solid var(--border-color);
  
  &:last-child {
    border-bottom: none;
  }
`

const QuestionLink = styled(Link)`
  color: var(--primary-color);
  text-decoration: none;
  font-weight: 500;
  
  &:hover {
    text-decoration: underline;
  }
`

const QuestionMeta = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 5px;
  font-size: 0.9rem;
  color: #6c757d;
`

const LoadingSpinner = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 30px;
  
  svg {
    animation: spin 1s linear infinite;
  }
  
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`

function Dashboard({ models, loading }) {
  const [questions, setQuestions] = useState([])
  const [stats, setStats] = useState({
    totalQuestions: 0,
    totalModels: 0,
    totalErrors: 0
  })
  const [loadingQuestions, setLoadingQuestions] = useState(true)
  
  useEffect(() => {
    // Fetch recent questions
    const fetchQuestions = async () => {
      try {
        const response = await fetch('/api/questions')
        if (response.ok) {
          const data = await response.json()
          setQuestions(data.slice(0, 5)) // Get only the 5 most recent questions
          setStats(prev => ({ ...prev, totalQuestions: data.length }))
        } else {
          console.error('Failed to fetch questions')
        }
      } catch (error) {
        console.error('Error fetching questions:', error)
      } finally {
        setLoadingQuestions(false)
      }
    }
    
    // Fetch error flags
    const fetchErrors = async () => {
      try {
        const response = await fetch('/api/error-flags')
        if (response.ok) {
          const data = await response.json()
          setStats(prev => ({ ...prev, totalErrors: data.length }))
        }
      } catch (error) {
        console.error('Error fetching error flags:', error)
      }
    }
    
    fetchQuestions()
    fetchErrors()
  }, [])
  
  useEffect(() => {
    if (models) {
      setStats(prev => ({ ...prev, totalModels: models.length }))
    }
  }, [models])
  
  if (loading) {
    return (
      <LoadingSpinner>
        <FaSpinner size={40} />
      </LoadingSpinner>
    )
  }
  
  return (
    <div>
      <h1>Dashboard</h1>
      
      <DashboardContainer>
        <DashboardCard>
          <CardTitle>Total Questions</CardTitle>
          <CardValue>{stats.totalQuestions}</CardValue>
          <p>Questions processed by the system</p>
        </DashboardCard>
        
        <DashboardCard>
          <CardTitle>Available Models</CardTitle>
          <CardValue>{stats.totalModels}</CardValue>
          <p>Ollama models ready for use</p>
        </DashboardCard>
        
        <DashboardCard>
          <CardTitle>Error Flags</CardTitle>
          <CardValue>{stats.totalErrors}</CardValue>
          <p>Issues requiring attention</p>
        </DashboardCard>
      </DashboardContainer>
      
      <RecentQuestionsContainer>
        <h2>Recent Questions</h2>
        
        {loadingQuestions ? (
          <LoadingSpinner>
            <FaSpinner size={20} />
          </LoadingSpinner>
        ) : questions.length > 0 ? (
          questions.map(question => (
            <QuestionItem key={question.id}>
              <QuestionLink to={`/question/${question.id}`}>
                {question.text.length > 100 ? `${question.text.substring(0, 100)}...` : question.text}
              </QuestionLink>
              <QuestionMeta>
                <span>ID: {question.id}</span>
                <span>{new Date(question.timestamp).toLocaleString()}</span>
              </QuestionMeta>
            </QuestionItem>
          ))
        ) : (
          <p>No questions have been processed yet.</p>
        )}
        
        {questions.length > 0 && (
          <div style={{ marginTop: '20px', textAlign: 'right' }}>
            <Link to="/history">View all questions</Link>
          </div>
        )}
      </RecentQuestionsContainer>
    </div>
  )
}

export default Dashboard

"""
Utility functions for evaluating model responses.
This module handles simple text evaluation metrics.
"""

from typing import List, Dict, Any, Tuple, Optional
import json

class ResponseEvaluator:
    """Class for evaluating model responses using multiple metrics."""

    def __init__(self):
        """Initialize the evaluator."""
        pass

    def tokenize(self, text: str) -> List[str]:
        """
        Tokenize text into words using simple splitting.

        Args:
            text (str): Text to tokenize

        Returns:
            List[str]: List of tokens
        """
        # Convert to lowercase and split by whitespace
        tokens = text.lower().split()

        # Remove punctuation from tokens
        cleaned_tokens = []
        for token in tokens:
            cleaned_token = ''.join(c for c in token if c.isalnum() or c == '-')
            if cleaned_token:
                cleaned_tokens.append(cleaned_token)

        return cleaned_tokens

    def calculate_jaccard_similarity(self, text1: str, text2: str) -> float:
        """
        Calculate Jaccard similarity between two texts (intersection over union).

        Args:
            text1 (str): First text
            text2 (str): Second text

        Returns:
            float: Similarity score between 0 and 1
        """
        # Get tokens as sets
        tokens1 = set(self.tokenize(text1))
        tokens2 = set(self.tokenize(text2))

        # Find intersection and union
        intersection = tokens1.intersection(tokens2)
        union = tokens1.union(tokens2)

        # Calculate Jaccard similarity
        if len(union) == 0:
            return 0.0

        return len(intersection) / len(union)

    def calculate_dice_coefficient(self, text1: str, text2: str) -> float:
        """
        Calculate Dice coefficient between two texts (2 * intersection / sum of sizes).

        Args:
            text1 (str): First text
            text2 (str): Second text

        Returns:
            float: Similarity score between 0 and 1
        """
        # Get tokens as sets
        tokens1 = set(self.tokenize(text1))
        tokens2 = set(self.tokenize(text2))

        # Calculate intersection
        intersection = tokens1.intersection(tokens2)

        # Calculate Dice coefficient
        if len(tokens1) + len(tokens2) == 0:
            return 0.0

        return 2 * len(intersection) / (len(tokens1) + len(tokens2))

    def calculate_overlap_coefficient(self, text1: str, text2: str) -> float:
        """
        Calculate overlap coefficient between two texts (intersection / min size).

        Args:
            text1 (str): First text
            text2 (str): Second text

        Returns:
            float: Similarity score between 0 and 1
        """
        # Get tokens as sets
        tokens1 = set(self.tokenize(text1))
        tokens2 = set(self.tokenize(text2))

        # Calculate intersection
        intersection = tokens1.intersection(tokens2)

        # Calculate overlap coefficient
        min_size = min(len(tokens1), len(tokens2))
        if min_size == 0:
            return 0.0

        return len(intersection) / min_size

    def calculate_length_ratio(self, text1: str, text2: str) -> float:
        """
        Calculate the ratio of lengths between two texts.

        Args:
            text1 (str): First text
            text2 (str): Second text

        Returns:
            float: Ratio between 0 and 1, where 1 means equal length
        """
        len1 = len(self.tokenize(text1))
        len2 = len(self.tokenize(text2))

        if len1 == 0 and len2 == 0:
            return 1.0
        if len1 == 0 or len2 == 0:
            return 0.0

        # Return the ratio of the smaller to the larger
        return min(len1, len2) / max(len1, len2)

    def evaluate_responses(self, responses: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, float]]:
        """
        Evaluate all model responses against each other using multiple metrics.

        Args:
            responses (Dict[str, Dict[str, Any]]): Dictionary mapping model names to their responses

        Returns:
            Dict[str, Dict[str, float]]: Dictionary mapping model names to their evaluation scores
        """
        models = list(responses.keys())
        scores = {model: {} for model in models}

        # For each model, calculate scores against all other models
        for i, model1 in enumerate(models):
            response1 = responses[model1]["response"]

            # Skip models with errors or timeouts
            if responses[model1]["status"] != "success" or not response1:
                scores[model1] = {
                    "jaccard_similarity": 0.0,
                    "dice_coefficient": 0.0,
                    "overlap_coefficient": 0.0,
                    "length_ratio": 0.0,
                    "overall_score": 0.0
                }
                continue

            jaccard_scores = []
            dice_scores = []
            overlap_scores = []
            length_ratio_scores = []

            for j, model2 in enumerate(models):
                if i == j:  # Skip comparing model to itself
                    continue

                response2 = responses[model2]["response"]

                # Skip models with errors or timeouts
                if responses[model2]["status"] != "success" or not response2:
                    continue

                # Calculate all metrics
                jaccard = self.calculate_jaccard_similarity(response1, response2)
                dice = self.calculate_dice_coefficient(response1, response2)
                overlap = self.calculate_overlap_coefficient(response1, response2)
                length_ratio = self.calculate_length_ratio(response1, response2)

                jaccard_scores.append(jaccard)
                dice_scores.append(dice)
                overlap_scores.append(overlap)
                length_ratio_scores.append(length_ratio)

            # Calculate averages
            avg_jaccard = sum(jaccard_scores) / len(jaccard_scores) if jaccard_scores else 0.0
            avg_dice = sum(dice_scores) / len(dice_scores) if dice_scores else 0.0
            avg_overlap = sum(overlap_scores) / len(overlap_scores) if overlap_scores else 0.0
            avg_length_ratio = sum(length_ratio_scores) / len(length_ratio_scores) if length_ratio_scores else 0.0

            # Calculate weighted overall score
            # Weights can be adjusted based on importance of each metric
            overall_score = (
                0.35 * avg_jaccard +
                0.25 * avg_dice +
                0.25 * avg_overlap +
                0.15 * avg_length_ratio
            )

            scores[model1] = {
                "jaccard_similarity": avg_jaccard,
                "dice_coefficient": avg_dice,
                "overlap_coefficient": avg_overlap,
                "length_ratio": avg_length_ratio,
                "overall_score": overall_score
            }

        return scores

    def select_best_model(self, scores: Dict[str, Dict[str, float]]) -> Tuple[str, float]:
        """
        Select the best model based on evaluation scores.

        Args:
            scores (Dict[str, Dict[str, float]]): Dictionary mapping model names to their evaluation scores

        Returns:
            Tuple[str, float]: Name of the best model and its overall score
        """
        best_model = None
        best_score = -1.0

        for model, model_scores in scores.items():
            overall_score = model_scores.get("overall_score", 0.0)
            if overall_score > best_score:
                best_score = overall_score
                best_model = model

        return best_model, best_score

    def evaluate_test_response(self, response: str, test_category: str) -> float:
        """
        Evaluate a model's response to a test question using simple heuristics.

        Args:
            response (str): The model's response
            test_category (str): Category of the test ("genel", "custom", or "stratejik")

        Returns:
            float: Score for the response between 0 and 1
        """
        if not response:
            return 0.0

        score = 0.0

        # Basic length check (longer responses are generally more detailed)
        length_score = min(len(response) / 1000, 1.0)  # Cap at 1.0
        score += 0.3 * length_score

        # Check for structured content
        structure_score = 0.0
        if ":" in response:  # Simple check for structured content
            structure_score += 0.2
        if "\n" in response:  # Check for multiple paragraphs
            structure_score += 0.2
        if any(marker in response.lower() for marker in ["first", "second", "third", "1.", "2.", "3."]):
            structure_score += 0.2

        score += 0.4 * min(structure_score, 1.0)  # Cap at 1.0

        # Check for category-specific content
        category_score = 0.0
        if test_category == "genel":
            if any(term in response.lower() for term in ["example", "instance", "case", "scenario"]):
                category_score += 0.3
            if any(term in response.lower() for term in ["however", "although", "nevertheless", "conversely"]):
                category_score += 0.3  # Rewards nuanced thinking
        elif test_category == "custom":
            if any(term in response.lower() for term in ["specific", "particular", "unique", "specialized"]):
                category_score += 0.3
            if any(term in response.lower() for term in ["domain", "field", "area", "expertise"]):
                category_score += 0.3
        elif test_category == "stratejik":
            if any(term in response.lower() for term in ["long-term", "strategy", "plan", "approach"]):
                category_score += 0.3
            if any(term in response.lower() for term in ["future", "anticipate", "predict", "forecast"]):
                category_score += 0.3

        score += 0.3 * min(category_score, 1.0)  # Cap at 1.0

        return score

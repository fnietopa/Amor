"""
Export and import utilities for the NeuraMirror Core MVP.
This module handles exporting and importing data for backup and sharing.
"""

import os
import json
import sqlite3
import zipfile
import tempfile
import shutil
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple

import db_module

def export_data(output_path: str = None) -> str:
    """
    Export all data from the database to a zip file.
    
    Args:
        output_path (str, optional): Path to save the export file. If None, a default path is used.
        
    Returns:
        str: Path to the exported zip file
    """
    # Create a timestamp for the export file
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # If no output path is provided, use a default path
    if output_path is None:
        output_path = f"neuramirror_export_{timestamp}.zip"
    
    # Create a temporary directory to store the export files
    with tempfile.TemporaryDirectory() as temp_dir:
        # Export the database to a JSON file
        db_path = os.path.join(temp_dir, "database.json")
        export_database_to_json(db_path)
        
        # Export the users file if it exists
        users_path = os.path.join(temp_dir, "users.json")
        if os.path.exists("users.json"):
            shutil.copy("users.json", users_path)
        
        # Create a metadata file
        metadata_path = os.path.join(temp_dir, "metadata.json")
        metadata = {
            "export_date": datetime.now().isoformat(),
            "version": "1.0.0",
            "description": "NeuraMirror Core MVP data export"
        }
        with open(metadata_path, "w") as f:
            json.dump(metadata, f, indent=2)
        
        # Create a zip file with all the exported files
        with zipfile.ZipFile(output_path, "w") as zipf:
            for root, _, files in os.walk(temp_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, temp_dir)
                    zipf.write(file_path, arcname)
    
    return output_path

def export_database_to_json(output_path: str) -> None:
    """
    Export the database to a JSON file.
    
    Args:
        output_path (str): Path to save the JSON file
    """
    conn = sqlite3.connect(db_module.DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    # Get all tables in the database
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [row["name"] for row in cursor.fetchall()]
    
    # Export each table to a dictionary
    data = {}
    for table in tables:
        cursor.execute(f"SELECT * FROM {table}")
        rows = cursor.fetchall()
        data[table] = [dict(row) for row in rows]
    
    # Write the data to a JSON file
    with open(output_path, "w") as f:
        json.dump(data, f, indent=2)
    
    conn.close()

def import_data(import_path: str) -> Tuple[bool, str]:
    """
    Import data from a zip file.
    
    Args:
        import_path (str): Path to the import zip file
        
    Returns:
        Tuple[bool, str]: Success status and message
    """
    # Create a temporary directory to extract the import files
    with tempfile.TemporaryDirectory() as temp_dir:
        try:
            # Extract the zip file
            with zipfile.ZipFile(import_path, "r") as zipf:
                zipf.extractall(temp_dir)
            
            # Check if the required files exist
            db_path = os.path.join(temp_dir, "database.json")
            metadata_path = os.path.join(temp_dir, "metadata.json")
            
            if not os.path.exists(db_path) or not os.path.exists(metadata_path):
                return False, "Invalid import file: missing required files"
            
            # Read the metadata
            with open(metadata_path, "r") as f:
                metadata = json.load(f)
            
            # Check the version
            if metadata.get("version", "0.0.0") != "1.0.0":
                return False, f"Unsupported import version: {metadata.get('version', 'unknown')}"
            
            # Import the database
            import_database_from_json(db_path)
            
            # Import the users file if it exists
            users_path = os.path.join(temp_dir, "users.json")
            if os.path.exists(users_path):
                shutil.copy(users_path, "users.json")
            
            return True, "Import successful"
        except Exception as e:
            return False, f"Import failed: {str(e)}"

def import_database_from_json(import_path: str) -> None:
    """
    Import the database from a JSON file.
    
    Args:
        import_path (str): Path to the JSON file
    """
    # Read the JSON file
    with open(import_path, "r") as f:
        data = json.load(f)
    
    # Create a new database connection
    conn = sqlite3.connect(db_module.DB_FILE)
    cursor = conn.cursor()
    
    # Import each table
    for table, rows in data.items():
        if not rows:
            continue
        
        # Get the column names from the first row
        columns = list(rows[0].keys())
        
        # Clear the table
        cursor.execute(f"DELETE FROM {table}")
        
        # Insert the rows
        for row in rows:
            placeholders = ", ".join(["?"] * len(columns))
            column_names = ", ".join(columns)
            values = [row[column] for column in columns]
            
            cursor.execute(f"INSERT INTO {table} ({column_names}) VALUES ({placeholders})", values)
    
    # Commit the changes
    conn.commit()
    conn.close()

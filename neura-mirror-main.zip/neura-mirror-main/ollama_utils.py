"""
Utility functions for interacting with Ollama models.
This module handles model discovery, listing, and querying.
"""

import json
import subprocess
import requests
import asyncio
import time
from typing import List, Dict, Any, Optional, Tuple

# Ollama API endpoint
OLLAMA_API_URL = "http://localhost:11434/api"

def list_models() -> List[Dict[str, Any]]:
    """
    List all available Ollama models using the Ollama CLI.

    Returns:
        List[Dict[str, Any]]: List of model information dictionaries
    """
    try:
        result = subprocess.run(
            ["ollama", "list", "--json"],
            capture_output=True,
            text=True,
            check=True
        )
        models = json.loads(result.stdout)
        return models
    except subprocess.CalledProcessError as e:
        print(f"Error listing models: {e}")
        return []
    except json.JSONDecodeError as e:
        print(f"Error parsing model list: {e}")
        return []

def list_models_api() -> List[Dict[str, Any]]:
    """
    List all available Ollama models using the Ollama API.

    Returns:
        List[Dict[str, Any]]: List of model information dictionaries
    """
    try:
        response = requests.get(f"{OLLAMA_API_URL}/tags")
        if response.status_code == 200:
            return response.json().get("models", [])
        else:
            print(f"Error listing models via API: {response.status_code}")
            return []
    except requests.RequestException as e:
        print(f"Error connecting to Ollama API: {e}")
        return []

def query_model(model_name: str, prompt: str, params: Dict[str, Any] = None) -> Tuple[str, float]:
    """
    Query a single Ollama model with a prompt.

    Args:
        model_name (str): Name of the model to query
        prompt (str): The prompt to send to the model
        params (Dict[str, Any], optional): Parameters for the model. Defaults to None.

    Returns:
        Tuple[str, float]: The model's response and the time taken in seconds
    """
    if params is None:
        params = {}

    default_params = {
        "num_predict": 1024,
        "temperature": 0.7,
        "top_k": 40,
        "top_p": 0.9,
        "repeat_penalty": 1.1,
        "stop": []
    }

    # Merge default params with provided params
    request_params = {**default_params, **params}
    request_params["model"] = model_name
    request_params["prompt"] = prompt

    start_time = time.time()
    try:
        response = requests.post(
            f"{OLLAMA_API_URL}/generate",
            json=request_params,
            timeout=60  # Long timeout for potentially slow models
        )

        if response.status_code == 200:
            try:
                # First try to parse the entire response as JSON
                try:
                    response_data = json.loads(response.text)
                    elapsed_time = time.time() - start_time
                    return response_data.get("response", ""), elapsed_time
                except json.JSONDecodeError:
                    # If that fails, try to parse just the first line
                    response_text = response.text.split('\n')[0]
                    response_data = json.loads(response_text)
                    elapsed_time = time.time() - start_time
                    return response_data.get("response", ""), elapsed_time
            except json.JSONDecodeError:
                # If JSON parsing fails, try multiple extraction methods
                extracted_response = ""

                # Method 1: Look for the response field in the text
                try:
                    if '"response":"' in response.text:
                        start_idx = response.text.find('"response":"') + len('"response":"')
                        end_idx = response.text.find('"', start_idx)
                        if start_idx > 0 and end_idx > start_idx:
                            extracted_response = response.text[start_idx:end_idx]
                    elif '"response":' in response.text:
                        # Handle case where response might not be in quotes
                        start_idx = response.text.find('"response":') + len('"response":')
                        # Find the next comma or closing brace
                        comma_idx = response.text.find(',', start_idx)
                        brace_idx = response.text.find('}', start_idx)
                        end_idx = min(x for x in [comma_idx, brace_idx] if x > 0)
                        if start_idx > 0 and end_idx > start_idx:
                            extracted_response = response.text[start_idx:end_idx].strip('" ')
                except Exception as e:
                    print(f"Method 1 error: {e}")

                # Method 2: Try to extract content between the first and last quotes
                if not extracted_response:
                    try:
                        first_quote = response.text.find('"', response.text.find('{'))
                        if first_quote > 0:
                            second_quote = response.text.find('"', first_quote + 1)
                            if second_quote > first_quote:
                                extracted_response = response.text[first_quote+1:second_quote]
                    except Exception as e:
                        print(f"Method 2 error: {e}")

                # Method 3: Just take the text after the first opening brace
                if not extracted_response:
                    try:
                        brace_idx = response.text.find('{')
                        if brace_idx >= 0:
                            extracted_response = response.text[brace_idx:].strip()
                    except Exception as e:
                        print(f"Method 3 error: {e}")

                if extracted_response:
                    return extracted_response, time.time() - start_time
                else:
                    print(f"Error parsing response from {model_name}: {response.text[:100]}...")
                    return f"Error: Could not parse response", time.time() - start_time
        else:
            print(f"Error querying model {model_name}: {response.status_code}")
            return f"Error: {response.status_code}", time.time() - start_time
    except requests.RequestException as e:
        elapsed_time = time.time() - start_time
        print(f"Exception querying model {model_name}: {e}")
        return f"Error: {str(e)}", elapsed_time

async def query_model_async(model_name: str, prompt: str, params: Dict[str, Any] = None) -> Tuple[str, float]:
    """
    Asynchronously query a single Ollama model with a prompt.

    Args:
        model_name (str): Name of the model to query
        prompt (str): The prompt to send to the model
        params (Dict[str, Any], optional): Parameters for the model. Defaults to None.

    Returns:
        Tuple[str, float]: The model's response and the time taken in seconds
    """
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, query_model, model_name, prompt, params)

async def query_all_models(prompt: str, models: List[str] = None, params: Dict[str, Any] = None, timeout: int = 120) -> Dict[str, Dict[str, Any]]:
    """
    Query all specified Ollama models with a prompt in parallel.

    Args:
        prompt (str): The prompt to send to all models
        models (List[str], optional): List of model names to query. If None, all available models are queried.
        params (Dict[str, Any], optional): Parameters for the models. Defaults to None.
        timeout (int, optional): Timeout in seconds. Defaults to 120.

    Returns:
        Dict[str, Dict[str, Any]]: Dictionary mapping model names to their responses and metadata
    """
    if models is None:
        # Get all available models if none specified
        models_info = list_models_api()
        models = [model["name"] for model in models_info]

    tasks = []
    for model_name in models:
        task = asyncio.create_task(query_model_async(model_name, prompt, params))
        tasks.append((model_name, task))

    results = {}
    for model_name, task in tasks:
        try:
            response, elapsed_time = await asyncio.wait_for(task, timeout=timeout)
            results[model_name] = {
                "response": response,
                "elapsed_time": elapsed_time,
                "status": "success" if not response.startswith("Error:") else "error"
            }
        except asyncio.TimeoutError:
            results[model_name] = {
                "response": "",
                "elapsed_time": timeout,
                "status": "timeout"
            }

    return results

def query_all_models_sync(prompt: str, models: List[str] = None, params: Dict[str, Any] = None, timeout: int = 120) -> Dict[str, Dict[str, Any]]:
    """
    Query all specified Ollama models with a prompt sequentially.

    Args:
        prompt (str): The prompt to send to all models
        models (List[str], optional): List of model names to query. If None, all available models are queried.
        params (Dict[str, Any], optional): Parameters for the models. Defaults to None.
        timeout (int, optional): Timeout in seconds. Defaults to 120.

    Returns:
        Dict[str, Dict[str, Any]]: Dictionary mapping model names to their responses and metadata
    """
    if models is None:
        # Get all available models if none specified
        models_info = list_models_api()
        models = [model["name"] for model in models_info]

    results = {}
    for model_name in models:
        try:
            response, elapsed_time = query_model(model_name, prompt, params)
            results[model_name] = {
                "response": response,
                "elapsed_time": elapsed_time,
                "status": "success" if not response.startswith("Error:") else "error"
            }
        except Exception as e:
            results[model_name] = {
                "response": f"Error: {str(e)}",
                "elapsed_time": 0,
                "status": "error"
            }

    return results

def query_model_for_expertise(model_name: str, params: Dict[str, Any] = None) -> Dict[str, List[str]]:
    """
    Query a model to determine its areas of expertise and language proficiency.

    Args:
        model_name (str): Name of the model to query
        params (Dict[str, Any], optional): Parameters for the model. Defaults to None.

    Returns:
        Dict[str, List[str]]: Dictionary mapping expertise areas to lists of languages
    """
    expertise_prompt = """
    Please analyze your capabilities and provide a structured response about your areas of expertise and language proficiency.

    Format your response as a JSON object with the following structure:
    {
        "expertise_areas": [
            {"name": "area_name", "confidence": 0.0-1.0, "languages": ["language1", "language2"]}
        ]
    }

    For example:
    {
        "expertise_areas": [
            {"name": "Programming", "confidence": 0.9, "languages": ["Python", "JavaScript", "C++"]},
            {"name": "Mathematics", "confidence": 0.8, "languages": ["English", "German"]}
        ]
    }

    Only include areas where your confidence is at least 0.7 on a scale from 0 to 1.
    """

    response, _ = query_model(model_name, expertise_prompt, params)

    try:
        # Try to extract JSON from the response
        json_start = response.find('{')
        json_end = response.rfind('}') + 1

        if json_start >= 0 and json_end > json_start:
            json_str = response[json_start:json_end]
            expertise_data = json.loads(json_str)

            # Convert to the expected format
            result = {}
            for area in expertise_data.get("expertise_areas", []):
                result[area["name"]] = area["languages"]

            return result
        else:
            print(f"Could not find JSON in response from {model_name}")
            return {}
    except json.JSONDecodeError as e:
        print(f"Error parsing expertise response from {model_name}: {e}")
        print(f"Response: {response}")
        return {}
    except Exception as e:
        print(f"Unexpected error processing expertise response from {model_name}: {e}")
        return {}

"""
Utility functions for generating and evaluating test questions.
This module handles question generation for expertise testing and model self-testing.
"""

from typing import Dict, List, Any, Tuple, Optional
import random
from ollama_utils import query_model

def generate_question_for_field_language(field: str, language: str, model: str, params: Dict[str, Any] = None) -> str:
    """
    Generate a question for a specific field and language using a model.
    
    Args:
        field (str): The expertise field
        language (str): The language to use
        model (str): The model to use for generating the question
        params (Dict[str, Any], optional): Parameters for the model. Defaults to None.
        
    Returns:
        str: The generated question
    """
    prompt = f"""
    Please generate a challenging question about {field} in {language}.
    
    The question should:
    1. Be specific to the field of {field}
    2. Require deep knowledge to answer correctly
    3. Be written entirely in {language}
    4. Be clear and unambiguous
    5. Be answerable in a few paragraphs
    
    Return only the question without any additional text or explanation.
    """
    
    response, _ = query_model(model, prompt, params)
    
    # Clean up the response
    question = response.strip()
    
    # If the response is too long, truncate it
    if len(question) > 500:
        question = question[:497] + "..."
    
    return question

def generate_test_question(model: str, test_category: str, params: Dict[str, Any] = None) -> str:
    """
    Generate a test question for a specific category using a model.
    
    Args:
        model (str): The model to use for generating the question
        test_category (str): The category of the test ("genel", "custom", or "stratejik")
        params (Dict[str, Any], optional): Parameters for the model. Defaults to None.
        
    Returns:
        str: The generated question
    """
    if test_category == "genel":
        prompt = """
        Generate a challenging general knowledge question that tests broad understanding and reasoning.
        
        The question should:
        1. Cover a topic that educated individuals should be familiar with
        2. Require critical thinking and analysis
        3. Be clear and unambiguous
        4. Be answerable in a few paragraphs
        
        Return only the question without any additional text or explanation.
        """
    elif test_category == "custom":
        prompt = """
        Generate a challenging question about a specialized domain or field.
        
        The question should:
        1. Focus on a specific domain (e.g., quantum physics, Renaissance art, machine learning)
        2. Require specialized knowledge to answer correctly
        3. Test deep understanding rather than surface-level facts
        4. Be clear and unambiguous
        5. Be answerable in a few paragraphs
        
        Return only the question without any additional text or explanation.
        """
    elif test_category == "stratejik":
        prompt = """
        Generate a challenging question that requires strategic thinking and long-term planning.
        
        The question should:
        1. Present a complex scenario or problem
        2. Require developing a multi-step strategy or approach
        3. Involve considering future implications and contingencies
        4. Test innovative thinking and problem-solving
        5. Be answerable in a few paragraphs
        
        Return only the question without any additional text or explanation.
        """
    else:
        return f"Unknown test category: {test_category}"
    
    response, _ = query_model(model, prompt, params)
    
    # Clean up the response
    question = response.strip()
    
    # If the response is too long, truncate it
    if len(question) > 500:
        question = question[:497] + "..."
    
    return question

def evaluate_field_response(response: str, reference_criteria: Dict[str, Any]) -> Dict[str, float]:
    """
    Evaluate a model's response to a field-specific question.
    
    Args:
        response (str): The model's response
        reference_criteria (Dict[str, Any]): Criteria for evaluation
        
    Returns:
        Dict[str, float]: Evaluation scores
    """
    # This is a placeholder implementation. In a real-world scenario, you would
    # implement more sophisticated evaluation logic based on the reference criteria.
    
    if not response:
        return {"relevance": 0.0, "depth": 0.0, "clarity": 0.0, "overall": 0.0}
    
    # Simple heuristics for evaluation
    
    # Relevance: Check if the response contains key terms from the criteria
    key_terms = reference_criteria.get("key_terms", [])
    relevance_score = 0.0
    if key_terms:
        matches = sum(1 for term in key_terms if term.lower() in response.lower())
        relevance_score = min(matches / len(key_terms), 1.0)
    
    # Depth: Evaluate based on response length and structure
    depth_score = min(len(response) / 1000, 1.0)  # Cap at 1.0
    
    # Clarity: Check for structured content
    clarity_score = 0.0
    if ":" in response:  # Simple check for structured content
        clarity_score += 0.3
    if "\n" in response:  # Check for multiple paragraphs
        clarity_score += 0.3
    if any(marker in response.lower() for marker in ["first", "second", "third", "1.", "2.", "3."]):
        clarity_score += 0.4
    clarity_score = min(clarity_score, 1.0)  # Cap at 1.0
    
    # Overall score: weighted average of the individual scores
    overall_score = 0.4 * relevance_score + 0.4 * depth_score + 0.2 * clarity_score
    
    return {
        "relevance": relevance_score,
        "depth": depth_score,
        "clarity": clarity_score,
        "overall": overall_score
    }

def compute_average(scores: List[Dict[str, float]]) -> float:
    """
    Compute the average of a list of scores.
    
    Args:
        scores (List[Dict[str, float]]): List of score dictionaries
        
    Returns:
        float: Average score
    """
    if not scores:
        return 0.0
    
    overall_scores = [score.get("overall", 0.0) for score in scores]
    return sum(overall_scores) / len(overall_scores)

def generate_reference_criteria(field: str, language: str) -> Dict[str, Any]:
    """
    Generate reference criteria for evaluating responses to field-specific questions.
    
    Args:
        field (str): The expertise field
        language (str): The language of the question
        
    Returns:
        Dict[str, Any]: Reference criteria
    """
    # This is a placeholder implementation. In a real-world scenario, you would
    # generate more sophisticated criteria based on the field and language.
    
    # For now, we'll just provide some generic key terms for common fields
    key_terms = []
    
    if field.lower() in ["programming", "coding", "software development"]:
        key_terms = ["algorithm", "code", "function", "class", "variable", "data structure"]
    elif field.lower() in ["mathematics", "math"]:
        key_terms = ["theorem", "proof", "equation", "formula", "calculation", "problem"]
    elif field.lower() in ["physics"]:
        key_terms = ["force", "energy", "mass", "particle", "theory", "experiment"]
    elif field.lower() in ["history"]:
        key_terms = ["event", "period", "century", "war", "revolution", "civilization"]
    elif field.lower() in ["literature"]:
        key_terms = ["author", "novel", "character", "plot", "theme", "analysis"]
    else:
        # Generic terms for any field
        key_terms = ["concept", "theory", "analysis", "example", "application", "explanation"]
    
    return {
        "field": field,
        "language": language,
        "key_terms": key_terms,
        "min_length": 200,  # Minimum expected response length
        "max_length": 2000  # Maximum expected response length
    }

"""
FastAPI backend for the NeuraMirror Core MVP.
This module provides API endpoints for the web interface.
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends, Header, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional, Annotated
import asyncio
import json
import time
import sqlite3
import os

import ollama_utils
import eval_utils
import error_utils
import test_utils
import db_module
import run_mvp
import auth_utils
import export_import

# Initialize the database and auth system
db_module.init_db()
auth_utils.init_auth()

# Create the FastAPI app
app = FastAPI(title="NeuraMirror Core MVP API")

# OAuth2 password bearer for token authentication
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Authentication dependency
async def get_current_user(token: Annotated[str, Depends(oauth2_scheme)]):
    user = auth_utils.verify_token(token)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods
    allow_headers=["*"],  # Allow all headers
)

# Define request and response models
class QuestionRequest(BaseModel):
    question: str
    models: Optional[List[str]] = None
    params: Optional[Dict[str, Any]] = None

class ModelResponse(BaseModel):
    name: str
    size: int
    modified_at: str
    digest: str

class StatusResponse(BaseModel):
    status: str
    message: str
    data: Optional[Dict[str, Any]] = None

# Authentication models
class UserCreate(BaseModel):
    username: str
    password: str
    role: str = "user"

class UserLogin(BaseModel):
    username: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str

class UserResponse(BaseModel):
    username: str
    role: str
    created_at: str

# Background task queue
task_queue = {}

# Authentication endpoints
@app.post("/token", response_model=Token)
async def login_for_access_token(form_data: Annotated[OAuth2PasswordRequestForm, Depends()]):
    """Get an access token for authentication."""
    if not auth_utils.verify_password(form_data.username, form_data.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )

    access_token = auth_utils.generate_token(form_data.username)
    return {"access_token": access_token, "token_type": "bearer"}

@app.post("/users", response_model=UserResponse)
async def create_user(user: UserCreate, current_user: Annotated[dict, Depends(get_current_user)]):
    """Create a new user (admin only)."""
    if current_user.get("role") != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to create users"
        )

    try:
        new_user = auth_utils.create_user(user.username, user.password, user.role)
        return {
            "username": new_user["username"],
            "role": new_user["role"],
            "created_at": new_user["created_at"]
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/users/me", response_model=UserResponse)
async def read_users_me(current_user: Annotated[dict, Depends(get_current_user)]):
    """Get the current user's information."""
    return {
        "username": current_user["username"],
        "role": current_user["role"],
        "created_at": current_user["created_at"]
    }

@app.post("/logout")
async def logout(current_user: Annotated[dict, Depends(get_current_user)]):
    """Logout and invalidate the current token."""
    token = current_user.get("token")
    if token:
        auth_utils.invalidate_token(token)
    return {"message": "Successfully logged out"}

# API endpoints
@app.get("/")
async def root():
    """Root endpoint."""
    return {"message": "Welcome to NeuraMirror Core MVP API"}

@app.get("/models", response_model=List[ModelResponse])
async def get_models():
    """Get all available models."""
    models = ollama_utils.list_models_api()
    if not models:
        raise HTTPException(status_code=500, detail="Could not connect to Ollama API")
    return models

@app.post("/process", response_model=StatusResponse)
async def process_question(request: QuestionRequest, background_tasks: BackgroundTasks):
    """
    Process a question through the NeuraMirror pipeline.

    This is an asynchronous endpoint. It returns immediately with a task ID,
    and the processing continues in the background.
    """
    # Generate a task ID
    task_id = str(int(time.time()))

    # Store the task in the queue
    task_queue[task_id] = {
        "status": "pending",
        "message": "Task queued",
        "data": {
            "question": request.question,
            "models": request.models,
            "params": request.params
        }
    }

    # Start the background task
    background_tasks.add_task(
        process_question_background,
        task_id,
        request.question,
        request.models,
        request.params
    )

    return StatusResponse(
        status="pending",
        message="Task queued",
        data={"task_id": task_id}
    )

@app.get("/status/{task_id}", response_model=StatusResponse)
async def get_status(task_id: str):
    """Get the status of a task."""
    if task_id not in task_queue:
        raise HTTPException(status_code=404, detail="Task not found")

    task = task_queue[task_id]
    return StatusResponse(
        status=task["status"],
        message=task["message"],
        data=task["data"]
    )

@app.get("/questions", response_model=List[Dict[str, Any]])
async def get_questions():
    """Get all questions from the database."""
    conn = sqlite3.connect(db_module.DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM questions ORDER BY timestamp DESC")
    rows = cursor.fetchall()

    conn.close()

    return [dict(row) for row in rows]

@app.get("/question/{question_id}", response_model=Dict[str, Any])
async def get_question_details(question_id: int):
    """Get details for a specific question."""
    # Get the question
    question = db_module.get_question(question_id)
    if not question:
        raise HTTPException(status_code=404, detail="Question not found")

    # Get the responses
    responses = db_module.get_responses(question_id)

    # Get the best model
    best_model = db_module.get_best_model(question_id)

    # Combine the data
    result = {
        "question": question,
        "responses": responses,
        "best_model": best_model
    }

    return result

@app.get("/expertise/{model_name}", response_model=Dict[str, List[str]])
async def get_expertise(model_name: str):
    """Get expertise data for a specific model."""
    expertise = db_module.get_expertise(model_name)
    if not expertise:
        raise HTTPException(status_code=404, detail="Expertise data not found")

    return expertise

@app.get("/field-tests/{model_name}", response_model=List[Dict[str, Any]])
async def get_field_tests(model_name: str):
    """Get field tests for a specific model."""
    field_tests = db_module.get_field_tests(model_name)
    return field_tests

@app.get("/model-tests/{model_name}", response_model=List[Dict[str, Any]])
async def get_model_tests(model_name: str):
    """Get model tests for a specific model."""
    model_tests = db_module.get_model_tests(model_name)
    return model_tests

@app.get("/error-flags", response_model=List[Dict[str, Any]])
async def get_error_flags(model_name: Optional[str] = None):
    """Get error flags."""
    error_flags = db_module.get_error_flags(model_name)
    return error_flags

async def process_question_background(task_id: str, question: str, models: List[str] = None, params: Dict[str, Any] = None):
    """
    Process a question in the background.

    Args:
        task_id (str): The ID of the task
        question (str): The question to process
        models (List[str], optional): List of model names to use. Defaults to None.
        params (Dict[str, Any], optional): Parameters for the models. Defaults to None.
    """
    try:
        # Update task status
        task_queue[task_id]["status"] = "processing"
        task_queue[task_id]["message"] = "Processing question"

        # Process the question
        await run_mvp.process_question(question, models, params)

        # Update task status
        task_queue[task_id]["status"] = "completed"
        task_queue[task_id]["message"] = "Processing complete"
    except Exception as e:
        # Update task status on error
        task_queue[task_id]["status"] = "error"
        task_queue[task_id]["message"] = f"Error: {str(e)}"
        print(f"Error processing question: {e}")

# Export and import endpoints
@app.post("/export", response_model=Dict[str, str])
async def export_data(current_user: Annotated[dict, Depends(get_current_user)]):
    """Export all data to a zip file (admin only)."""
    if current_user.get("role") != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to export data"
        )

    try:
        export_path = export_import.export_data()
        return {"message": "Export successful", "file_path": export_path}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")

@app.post("/import", response_model=Dict[str, str])
async def import_data(import_path: str, current_user: Annotated[dict, Depends(get_current_user)]):
    """Import data from a zip file (admin only)."""
    if current_user.get("role") != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to import data"
        )

    if not os.path.exists(import_path):
        raise HTTPException(status_code=404, detail=f"Import file not found: {import_path}")

    success, message = export_import.import_data(import_path)
    if not success:
        raise HTTPException(status_code=500, detail=message)

    return {"message": message}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

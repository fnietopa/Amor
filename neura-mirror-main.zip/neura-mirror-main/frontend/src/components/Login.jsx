import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import styled from 'styled-components'
import { FaLock, FaUser } from 'react-icons/fa'
import axios from 'axios'

const LoginContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background-color: #f8f9fa;
  padding: 20px;
`

const LoginCard = styled.div`
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  padding: 30px;
  width: 100%;
  max-width: 400px;
`

const LoginHeader = styled.div`
  text-align: center;
  margin-bottom: 30px;
`

const LoginTitle = styled.h1`
  font-size: 1.8rem;
  color: var(--primary-color);
  margin-bottom: 10px;
`

const LoginSubtitle = styled.p`
  color: #6c757d;
  font-size: 1rem;
`

const LoginForm = styled.form`
  display: flex;
  flex-direction: column;
`

const FormGroup = styled.div`
  margin-bottom: 20px;
`

const InputGroup = styled.div`
  display: flex;
  align-items: center;
  border: 1px solid var(--border-color);
  border-radius: 4px;
  padding: 0 10px;
  
  &:focus-within {
    border-color: var(--primary-color);
    box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
  }
  
  svg {
    color: #6c757d;
    margin-right: 10px;
  }
`

const Input = styled.input`
  flex: 1;
  padding: 12px 0;
  border: none;
  outline: none;
  font-size: 1rem;
`

const LoginButton = styled.button`
  padding: 12px;
  background-color: var(--primary-color);
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 1rem;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.3s;
  
  &:hover {
    background-color: #2980b9;
  }
  
  &:disabled {
    background-color: #95a5a6;
    cursor: not-allowed;
  }
`

const ErrorMessage = styled.div`
  color: var(--error-color);
  margin-top: 20px;
  padding: 10px;
  background-color: #fde2e2;
  border-radius: 4px;
  text-align: center;
`

function Login({ onLogin }) {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  
  const navigate = useNavigate()
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!username || !password) {
      setError('Please enter both username and password')
      return
    }
    
    setLoading(true)
    setError('')
    
    try {
      // Create form data for the token endpoint
      const formData = new FormData()
      formData.append('username', username)
      formData.append('password', password)
      
      const response = await axios.post('/api/token', formData)
      const data = response.data
      
      // Store the token in localStorage
      localStorage.setItem('token', data.access_token)
      
      // Get user info
      const userResponse = await axios.get('/api/users/me', {
        headers: {
          'Authorization': `Bearer ${data.access_token}`
        }
      })
      
      const userData = userResponse.data
      
      // Store user data
      localStorage.setItem('user', JSON.stringify(userData))
      
      // Call the onLogin callback
      if (onLogin) {
        onLogin(userData)
      }
      
      // Redirect to dashboard
      navigate('/')
    } catch (error) {
      if (error.response && error.response.data) {
        setError(error.response.data.detail || 'Login failed')
      } else {
        setError(error.message || 'An error occurred during login')
      }
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <LoginContainer>
      <LoginCard>
        <LoginHeader>
          <LoginTitle>NeuraMirror Core MVP</LoginTitle>
          <LoginSubtitle>Sign in to access the dashboard</LoginSubtitle>
        </LoginHeader>
        
        <LoginForm onSubmit={handleSubmit}>
          <FormGroup>
            <InputGroup>
              <FaUser />
              <Input
                type="text"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                disabled={loading}
              />
            </InputGroup>
          </FormGroup>
          
          <FormGroup>
            <InputGroup>
              <FaLock />
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={loading}
              />
            </InputGroup>
          </FormGroup>
          
          <LoginButton type="submit" disabled={loading}>
            {loading ? 'Signing in...' : 'Sign In'}
          </LoginButton>
          
          {error && <ErrorMessage>{error}</ErrorMessage>}
        </LoginForm>
      </LoginCard>
    </LoginContainer>
  )
}

export default Login

import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import styled from 'styled-components'
import { FaSpinner, FaCheck, FaTimes, FaClock, FaChartBar } from 'react-icons/fa'
import { Bar, Radar } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  RadialLinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  RadialLinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const DetailsContainer = styled.div`
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-bottom: 20px;
`

const QuestionHeader = styled.div`
  margin-bottom: 20px;
  padding-bottom: 20px;
  border-bottom: 1px solid var(--border-color);
`

const QuestionText = styled.div`
  font-size: 1.2rem;
  margin-bottom: 10px;
`

const QuestionMeta = styled.div`
  display: flex;
  justify-content: space-between;
  font-size: 0.9rem;
  color: #6c757d;
`

const ResponsesContainer = styled.div`
  margin-top: 30px;
`

const ResponseCard = styled.div`
  background-color: ${props => props.isBest ? '#e8f4fd' : 'white'};
  border: 1px solid ${props => props.isBest ? '#3498db' : 'var(--border-color)'};
  border-radius: 8px;
  padding: 15px;
  margin-bottom: 15px;
  position: relative;

  ${props => props.isBest && `
    &::before {
      content: 'Best Response';
      position: absolute;
      top: -10px;
      right: 10px;
      background-color: #3498db;
      color: white;
      padding: 2px 10px;
      border-radius: 10px;
      font-size: 0.8rem;
      font-weight: bold;
    }
  `}
`

const ResponseHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
  padding-bottom: 10px;
  border-bottom: 1px solid var(--border-color);
`

const ModelName = styled.div`
  font-weight: bold;
  font-size: 1.1rem;
`

const ResponseStatus = styled.div`
  display: flex;
  align-items: center;

  svg {
    margin-right: 5px;
  }
`

const ResponseText = styled.div`
  white-space: pre-wrap;
  margin-bottom: 15px;
  font-family: monospace;
  background-color: #f8f9fa;
  padding: 10px;
  border-radius: 4px;
  max-height: 300px;
  overflow-y: auto;
`

const ScoresContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  gap: 10px;
  margin-top: 15px;
`

const ScoreItem = styled.div`
  background-color: #f8f9fa;
  padding: 10px;
  border-radius: 4px;
  text-align: center;
`

const ScoreLabel = styled.div`
  font-size: 0.8rem;
  color: #6c757d;
  margin-bottom: 5px;
`

const ScoreValue = styled.div`
  font-weight: bold;
  color: ${props => {
    if (props.value >= 0.7) return 'var(--success-color)';
    if (props.value >= 0.4) return 'var(--warning-color)';
    return 'var(--error-color)';
  }};
`

const ChartContainer = styled.div`
  margin-top: 20px;
  padding: 15px;
  background-color: #f8f9fa;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
`

const ChartHeader = styled.h4`
  margin-bottom: 15px;
  display: flex;
  align-items: center;

  svg {
    margin-right: 8px;
    color: var(--primary-color);
  }
`

const ChartGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`

const TabContainer = styled.div`
  margin-top: 20px;
`

const TabButtons = styled.div`
  display: flex;
  border-bottom: 1px solid var(--border-color);
  margin-bottom: 15px;
`

const TabButton = styled.button`
  padding: 10px 15px;
  background-color: ${props => props.active ? 'var(--primary-color)' : 'transparent'};
  color: ${props => props.active ? 'white' : 'var(--text-color)'};
  border: none;
  border-bottom: 2px solid ${props => props.active ? 'var(--primary-color)' : 'transparent'};
  cursor: pointer;

  &:hover {
    background-color: ${props => props.active ? 'var(--primary-color)' : '#f8f9fa'};
  }
`

const LoadingSpinner = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 50px;

  svg {
    animation: spin 1s linear infinite;
  }

  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`

const BackLink = styled(Link)`
  display: inline-block;
  margin-bottom: 20px;
  color: var(--primary-color);
  text-decoration: none;

  &:hover {
    text-decoration: underline;
  }
`

function QuestionDetails() {
  const { id } = useParams()
  const [questionData, setQuestionData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('responses')

  useEffect(() => {
    const fetchQuestionDetails = async () => {
      try {
        const response = await fetch(`/api/question/${id}`)
        if (response.ok) {
          const data = await response.json()
          setQuestionData(data)
        } else {
          console.error('Failed to fetch question details')
        }
      } catch (error) {
        console.error('Error fetching question details:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchQuestionDetails()
  }, [id])

  if (loading) {
    return (
      <LoadingSpinner>
        <FaSpinner size={40} />
      </LoadingSpinner>
    )
  }

  // Function to prepare bar chart data for model scores
  const prepareBarChartData = () => {
    if (!questionData || !questionData.best_model) return null;

    // Find the scores for the best model
    const bestModelScores = {};
    const allScores = [];

    // Collect all scores
    questionData.responses.forEach(response => {
      const modelName = response.model_name;
      if (modelName === questionData.best_model.model_name) {
        // This is a simplification - in a real app, you'd fetch the actual scores from the API
        bestModelScores.jaccard_similarity = 0.8;
        bestModelScores.dice_coefficient = 0.75;
        bestModelScores.overlap_coefficient = 0.85;
        bestModelScores.length_ratio = 0.7;
      }

      // Add to all scores for comparison
      allScores.push({
        model: modelName,
        // Simulated scores - in a real app, you'd fetch these from the API
        jaccard_similarity: Math.random() * 0.5 + 0.3,
        dice_coefficient: Math.random() * 0.5 + 0.3,
        overlap_coefficient: Math.random() * 0.5 + 0.3,
        length_ratio: Math.random() * 0.5 + 0.3
      });
    });

    return {
      labels: ['Jaccard Similarity', 'Dice Coefficient', 'Overlap Coefficient', 'Length Ratio'],
      datasets: [
        {
          label: questionData.best_model.model_name,
          data: [
            bestModelScores.jaccard_similarity || 0,
            bestModelScores.dice_coefficient || 0,
            bestModelScores.overlap_coefficient || 0,
            bestModelScores.length_ratio || 0
          ],
          backgroundColor: 'rgba(52, 152, 219, 0.6)',
          borderColor: 'rgba(52, 152, 219, 1)',
          borderWidth: 1
        }
      ]
    };
  };

  // Function to prepare radar chart data for model comparison
  const prepareRadarChartData = () => {
    if (!questionData) return null;

    const models = [];
    const datasets = [];
    const colors = [
      'rgba(52, 152, 219, 0.6)', // Blue
      'rgba(46, 204, 113, 0.6)', // Green
      'rgba(231, 76, 60, 0.6)',  // Red
      'rgba(241, 196, 15, 0.6)', // Yellow
      'rgba(155, 89, 182, 0.6)'  // Purple
    ];

    // Get unique models
    questionData.responses.forEach(response => {
      if (!models.includes(response.model_name)) {
        models.push(response.model_name);
      }
    });

    // Create a dataset for each model
    models.forEach((model, index) => {
      // Simulated scores - in a real app, you'd fetch these from the API
      datasets.push({
        label: model,
        data: [
          Math.random() * 0.5 + 0.3, // Jaccard
          Math.random() * 0.5 + 0.3, // Dice
          Math.random() * 0.5 + 0.3, // Overlap
          Math.random() * 0.5 + 0.3  // Length
        ],
        backgroundColor: colors[index % colors.length].replace('0.6', '0.2'),
        borderColor: colors[index % colors.length].replace('0.6', '1'),
        borderWidth: 2,
        pointBackgroundColor: colors[index % colors.length].replace('0.6', '1'),
        pointBorderColor: '#fff',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: colors[index % colors.length].replace('0.6', '1')
      });
    });

    return {
      labels: ['Jaccard Similarity', 'Dice Coefficient', 'Overlap Coefficient', 'Length Ratio'],
      datasets
    };
  };

  if (!questionData) {
    return <div>Question not found</div>
  }

  const { question, responses, best_model } = questionData

  // Group responses by model and get the latest attempt for each model
  const latestResponses = {}
  responses.forEach(response => {
    const modelName = response.model_name
    if (!latestResponses[modelName] || response.attempt > latestResponses[modelName].attempt) {
      latestResponses[modelName] = response
    }
  })

  // Prepare chart data
  const barChartData = prepareBarChartData();
  const radarChartData = prepareRadarChartData();

  // Chart options
  const barChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Best Model Scores'
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 1
      }
    }
  };

  const radarChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Model Comparison'
      }
    },
    scales: {
      r: {
        beginAtZero: true,
        max: 1,
        ticks: {
          stepSize: 0.2
        }
      }
    }
  };

  return (
    <div>
      <BackLink to="/history">&larr; Back to History</BackLink>

      <h1>Question Details</h1>

      <DetailsContainer>
        <QuestionHeader>
          <QuestionText>{question.text}</QuestionText>
          <QuestionMeta>
            <span>ID: {question.id}</span>
            <span>{new Date(question.timestamp).toLocaleString()}</span>
          </QuestionMeta>
        </QuestionHeader>

        {best_model && (
          <div>
            <h3>Best Model</h3>
            <p>
              <strong>{best_model.model_name}</strong> with a score of{' '}
              <strong>{best_model.score.toFixed(2)}</strong>
            </p>
          </div>
        )}

        <TabContainer>
          <TabButtons>
            <TabButton
              active={activeTab === 'responses'}
              onClick={() => setActiveTab('responses')}
            >
              Responses
            </TabButton>
            <TabButton
              active={activeTab === 'metrics'}
              onClick={() => setActiveTab('metrics')}
            >
              Metrics & Visualizations
            </TabButton>
          </TabButtons>

          {activeTab === 'responses' && (
            <ResponsesContainer>
              <h3>Model Responses</h3>

              {Object.values(latestResponses).map(response => {
            const isBestModel = best_model && response.model_name === best_model.model_name

            return (
              <ResponseCard key={response.id} isBest={isBestModel}>
                <ResponseHeader>
                  <ModelName>{response.model_name}</ModelName>
                  <ResponseStatus>
                    {response.status === 'success' ? (
                      <>
                        <FaCheck color="var(--success-color)" />
                        <span>Success</span>
                      </>
                    ) : response.status === 'timeout' ? (
                      <>
                        <FaClock color="var(--warning-color)" />
                        <span>Timeout</span>
                      </>
                    ) : (
                      <>
                        <FaTimes color="var(--error-color)" />
                        <span>Error</span>
                      </>
                    )}
                  </ResponseStatus>
                </ResponseHeader>

                <div>
                  <strong>Attempt:</strong> {response.attempt}
                </div>
                <div>
                  <strong>Time:</strong> {response.elapsed_time.toFixed(2)}s
                </div>

                <h4 style={{ marginTop: '15px', marginBottom: '10px' }}>Response:</h4>
                <ResponseText>
                  {response.response_text || 'No response'}
                </ResponseText>

                {isBestModel && (
                  <>
                    <h4>Evaluation Scores:</h4>
                    <ScoresContainer>
                      <ScoreItem>
                        <ScoreLabel>Overall</ScoreLabel>
                        <ScoreValue value={best_model.score}>
                          {best_model.score.toFixed(2)}
                        </ScoreValue>
                      </ScoreItem>

                      {/* Add more score items here if you have them in your data */}
                    </ScoresContainer>
                  </>
                )}
              </ResponseCard>
            )
          })}
            </ResponsesContainer>
          )}

          {activeTab === 'metrics' && (
            <div>
              <ChartContainer>
                <ChartHeader>
                  <FaChartBar /> Best Model Performance
                </ChartHeader>
                {barChartData && (
                  <div style={{ height: '300px' }}>
                    <Bar data={barChartData} options={barChartOptions} />
                  </div>
                )}
              </ChartContainer>

              <ChartContainer>
                <ChartHeader>
                  <FaChartBar /> Model Comparison
                </ChartHeader>
                {radarChartData && (
                  <div style={{ height: '400px' }}>
                    <Radar data={radarChartData} options={radarChartOptions} />
                  </div>
                )}
              </ChartContainer>

              <ChartContainer>
                <ChartHeader>
                  <FaChartBar /> Detailed Metrics
                </ChartHeader>
                <ChartGrid>
                  <div>
                    <h4>Similarity Metrics</h4>
                    <p>These metrics measure how similar the model responses are to each other:</p>
                    <ul>
                      <li><strong>Jaccard Similarity:</strong> Measures the similarity between sets by comparing the size of their intersection to the size of their union.</li>
                      <li><strong>Dice Coefficient:</strong> Similar to Jaccard but gives more weight to overlapping elements.</li>
                      <li><strong>Overlap Coefficient:</strong> Measures the overlap between two sets, focusing on the smaller set.</li>
                      <li><strong>Length Ratio:</strong> Compares the lengths of responses to ensure they are of similar size.</li>
                    </ul>
                  </div>
                  <div>
                    <h4>Interpretation</h4>
                    <p>Higher scores indicate better performance:</p>
                    <ul>
                      <li><strong>0.8-1.0:</strong> Excellent - Very high similarity or quality</li>
                      <li><strong>0.6-0.8:</strong> Good - Strong similarity or quality</li>
                      <li><strong>0.4-0.6:</strong> Moderate - Acceptable similarity or quality</li>
                      <li><strong>0.2-0.4:</strong> Poor - Low similarity or quality</li>
                      <li><strong>0.0-0.2:</strong> Very Poor - Very low similarity or quality</li>
                    </ul>
                  </div>
                </ChartGrid>
              </ChartContainer>
            </div>
          )}
        </TabContainer>
      </DetailsContainer>
    </div>
  )
}

export default QuestionDetails

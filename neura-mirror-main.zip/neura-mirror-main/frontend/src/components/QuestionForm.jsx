import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import styled from 'styled-components'
import { FaSpinner } from 'react-icons/fa'
import api from '../utils/api'

const FormContainer = styled.div`
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-bottom: 20px;
`

const Form = styled.form`
  display: flex;
  flex-direction: column;
`

const FormGroup = styled.div`
  margin-bottom: 20px;
`

const Label = styled.label`
  display: block;
  margin-bottom: 5px;
  font-weight: 500;
`

const TextArea = styled.textarea`
  width: 100%;
  padding: 10px;
  border: 1px solid var(--border-color);
  border-radius: 4px;
  font-size: 1rem;
  min-height: 150px;
`

const Select = styled.select`
  width: 100%;
  padding: 10px;
  border: 1px solid var(--border-color);
  border-radius: 4px;
  font-size: 1rem;
`

const SelectedModels = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: 10px;
`

const ModelTag = styled.div`
  background-color: var(--primary-color);
  color: white;
  padding: 5px 10px;
  border-radius: 20px;
  display: flex;
  align-items: center;

  button {
    background: none;
    border: none;
    color: white;
    margin-left: 5px;
    padding: 0;
    font-size: 1rem;
    cursor: pointer;
  }
`

const SubmitButton = styled.button`
  padding: 10px 15px;
  background-color: var(--primary-color);
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 1rem;
  cursor: pointer;
  transition: background-color 0.3s;

  &:hover {
    background-color: #2980b9;
  }

  &:disabled {
    background-color: #95a5a6;
    cursor: not-allowed;
  }
`

const LoadingOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  z-index: 1000;
  color: white;

  svg {
    margin-bottom: 20px;
    animation: spin 1s linear infinite;
  }

  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`

function QuestionForm({ models }) {
  const [question, setQuestion] = useState('')
  const [selectedModels, setSelectedModels] = useState([])
  const [currentModel, setCurrentModel] = useState('')
  const [loading, setLoading] = useState(false)
  const [taskId, setTaskId] = useState(null)
  const [taskStatus, setTaskStatus] = useState(null)
  const [statusMessage, setStatusMessage] = useState('')

  const navigate = useNavigate()

  // Poll for task status if a task is in progress
  useEffect(() => {
    let interval

    if (taskId && (taskStatus === 'pending' || taskStatus === 'processing')) {
      interval = setInterval(async () => {
        try {
          const response = await api.get(`/status/${taskId}`)
          const data = response.data
          setTaskStatus(data.status)
          setStatusMessage(data.message)

          if (data.status === 'completed') {
            clearInterval(interval)
            setLoading(false)
            // Navigate to the history page after a short delay
            setTimeout(() => {
              navigate('/history')
            }, 1000)
          } else if (data.status === 'error') {
            clearInterval(interval)
            setLoading(false)
            alert(`Error: ${data.message}`)
          }
        } catch (error) {
          console.error('Error checking task status:', error)
        }
      }, 2000)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [taskId, taskStatus, navigate])

  const handleAddModel = () => {
    if (currentModel && !selectedModels.includes(currentModel)) {
      setSelectedModels([...selectedModels, currentModel])
      setCurrentModel('')
    }
  }

  const handleRemoveModel = (model) => {
    setSelectedModels(selectedModels.filter(m => m !== model))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!question.trim()) {
      alert('Please enter a question')
      return
    }

    setLoading(true)

    try {
      const response = await api.post('/process', {
        question,
        models: selectedModels.length > 0 ? selectedModels : null
      })

      const data = response.data
      setTaskId(data.data.task_id)
      setTaskStatus(data.status)
      setStatusMessage(data.message)
    } catch (error) {
      console.error('Error submitting question:', error)
      alert('An error occurred while submitting the question')
      setLoading(false)
    }
  }

  return (
    <div>
      <h1>Ask a Question</h1>

      <FormContainer>
        <Form onSubmit={handleSubmit}>
          <FormGroup>
            <Label htmlFor="question">Your Question:</Label>
            <TextArea
              id="question"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Enter your question here..."
              required
            />
          </FormGroup>

          <FormGroup>
            <Label htmlFor="model">Select Models (Optional):</Label>
            <div style={{ display: 'flex', gap: '10px' }}>
              <Select
                id="model"
                value={currentModel}
                onChange={(e) => setCurrentModel(e.target.value)}
              >
                <option value="">Select a model</option>
                {models.map(model => (
                  <option key={model.name} value={model.name}>
                    {model.name}
                  </option>
                ))}
              </Select>
              <button type="button" onClick={handleAddModel} disabled={!currentModel}>
                Add
              </button>
            </div>

            {selectedModels.length > 0 && (
              <SelectedModels>
                {selectedModels.map(model => (
                  <ModelTag key={model}>
                    {model}
                    <button type="button" onClick={() => handleRemoveModel(model)}>
                      &times;
                    </button>
                  </ModelTag>
                ))}
              </SelectedModels>
            )}

            <p style={{ marginTop: '10px', fontSize: '0.9rem', color: '#6c757d' }}>
              If no models are selected, all available models will be used.
            </p>
          </FormGroup>

          <SubmitButton type="submit" disabled={loading || !question.trim()}>
            {loading ? 'Processing...' : 'Submit Question'}
          </SubmitButton>
        </Form>
      </FormContainer>

      {loading && (
        <LoadingOverlay>
          <FaSpinner size={50} />
          <h2>{statusMessage || 'Processing your question...'}</h2>
          <p>This may take a few minutes</p>
        </LoadingOverlay>
      )}
    </div>
  )
}

export default QuestionForm

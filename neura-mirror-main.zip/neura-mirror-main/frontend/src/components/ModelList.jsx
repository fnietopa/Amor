import { useState } from 'react'
import styled from 'styled-components'
import { FaSpinner } from 'react-icons/fa'

const ModelsContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
`

const ModelCard = styled.div`
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  padding: 20px;
  display: flex;
  flex-direction: column;
`

const ModelName = styled.h3`
  margin-bottom: 10px;
  color: var(--primary-color);
`

const ModelInfo = styled.div`
  margin-bottom: 5px;
  
  strong {
    margin-right: 5px;
  }
`

const ModelSize = styled.div`
  font-size: 0.9rem;
  color: #6c757d;
  margin-bottom: 15px;
`

const ModelActions = styled.div`
  margin-top: auto;
  display: flex;
  gap: 10px;
`

const ActionButton = styled.button`
  padding: 8px 12px;
  background-color: ${props => props.secondary ? '#6c757d' : 'var(--primary-color)'};
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  
  &:hover {
    background-color: ${props => props.secondary ? '#5a6268' : '#2980b9'};
  }
`

const LoadingSpinner = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 50px;
  
  svg {
    animation: spin 1s linear infinite;
  }
  
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`

const formatSize = (sizeInBytes) => {
  if (sizeInBytes < 1024) {
    return `${sizeInBytes} B`
  } else if (sizeInBytes < 1024 * 1024) {
    return `${(sizeInBytes / 1024).toFixed(2)} KB`
  } else if (sizeInBytes < 1024 * 1024 * 1024) {
    return `${(sizeInBytes / (1024 * 1024)).toFixed(2)} MB`
  } else {
    return `${(sizeInBytes / (1024 * 1024 * 1024)).toFixed(2)} GB`
  }
}

function ModelList({ models, loading }) {
  const [selectedModel, setSelectedModel] = useState(null)
  
  if (loading) {
    return (
      <LoadingSpinner>
        <FaSpinner size={40} />
      </LoadingSpinner>
    )
  }
  
  return (
    <div>
      <h1>Available Models</h1>
      
      {models.length === 0 ? (
        <p>No models found. Make sure Ollama is running and has models installed.</p>
      ) : (
        <ModelsContainer>
          {models.map(model => (
            <ModelCard key={model.name}>
              <ModelName>{model.name}</ModelName>
              <ModelSize>{formatSize(model.size)}</ModelSize>
              
              <ModelInfo>
                <strong>Modified:</strong>
                {new Date(model.modified_at).toLocaleString()}
              </ModelInfo>
              
              <ModelInfo>
                <strong>Digest:</strong>
                {model.digest.substring(0, 8)}...
              </ModelInfo>
              
              <ModelActions>
                <ActionButton onClick={() => setSelectedModel(model)}>
                  View Details
                </ActionButton>
                <ActionButton secondary>
                  Test Model
                </ActionButton>
              </ModelActions>
            </ModelCard>
          ))}
        </ModelsContainer>
      )}
      
      {/* Modal for model details (placeholder) */}
      {selectedModel && (
        <div style={{ marginTop: '20px', padding: '20px', backgroundColor: '#f8f9fa', borderRadius: '8px' }}>
          <h2>Model Details: {selectedModel.name}</h2>
          <p>This feature is coming soon.</p>
          <button onClick={() => setSelectedModel(null)}>Close</button>
        </div>
      )}
    </div>
  )
}

export default ModelList

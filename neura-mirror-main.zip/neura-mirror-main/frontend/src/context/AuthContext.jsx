import { createContext, useState, useEffect, useContext } from 'react'

// Create the auth context
const AuthContext = createContext()

// Custom hook to use the auth context
export const useAuth = () => {
  return useContext(AuthContext)
}

// Auth provider component
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  
  // Initialize auth state from localStorage
  useEffect(() => {
    const storedUser = localStorage.getItem('user')
    const token = localStorage.getItem('token')
    
    if (storedUser && token) {
      try {
        setUser(JSON.parse(storedUser))
      } catch (error) {
        console.error('Error parsing stored user:', error)
        localStorage.removeItem('user')
        localStorage.removeItem('token')
      }
    }
    
    setLoading(false)
  }, [])
  
  // Login function
  const login = (userData) => {
    setUser(userData)
    localStorage.setItem('user', JSON.stringify(userData))
  }
  
  // Logout function
  const logout = async () => {
    try {
      const token = localStorage.getItem('token')
      
      if (token) {
        // Call the logout endpoint
        await fetch('/api/logout', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        })
      }
    } catch (error) {
      console.error('Error during logout:', error)
    } finally {
      // Clear local storage and state
      localStorage.removeItem('user')
      localStorage.removeItem('token')
      setUser(null)
    }
  }
  
  // Check if the user is an admin
  const isAdmin = () => {
    return user && user.role === 'admin'
  }
  
  // Get the auth token
  const getToken = () => {
    return localStorage.getItem('token')
  }
  
  // Value to provide to consumers
  const value = {
    user,
    loading,
    login,
    logout,
    isAdmin,
    getToken
  }
  
  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

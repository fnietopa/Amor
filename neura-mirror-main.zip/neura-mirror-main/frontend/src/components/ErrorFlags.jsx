import { useState, useEffect } from 'react'
import styled from 'styled-components'
import { FaSpinner, FaExclamationTriangle } from 'react-icons/fa'

const ErrorsContainer = styled.div`
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-bottom: 20px;
`

const ErrorItem = styled.div`
  padding: 15px;
  margin-bottom: 15px;
  border-left: 4px solid var(--error-color);
  background-color: #fff5f5;
  border-radius: 0 4px 4px 0;
`

const ErrorHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
`

const ErrorTitle = styled.div`
  font-weight: bold;
  display: flex;
  align-items: center;
  
  svg {
    margin-right: 10px;
    color: var(--error-color);
  }
`

const ErrorMeta = styled.div`
  font-size: 0.9rem;
  color: #6c757d;
`

const ErrorDetails = styled.div`
  margin-top: 10px;
  padding-top: 10px;
  border-top: 1px solid #f1c1c0;
`

const LoadingSpinner = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 50px;
  
  svg {
    animation: spin 1s linear infinite;
  }
  
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`

const NoErrorsMessage = styled.div`
  text-align: center;
  padding: 30px;
  color: var(--success-color);
  font-weight: bold;
`

function ErrorFlags() {
  const [errors, setErrors] = useState([])
  const [loading, setLoading] = useState(true)
  
  useEffect(() => {
    const fetchErrors = async () => {
      try {
        const response = await fetch('/api/error-flags')
        if (response.ok) {
          const data = await response.json()
          setErrors(data)
        } else {
          console.error('Failed to fetch error flags')
        }
      } catch (error) {
        console.error('Error fetching error flags:', error)
      } finally {
        setLoading(false)
      }
    }
    
    fetchErrors()
  }, [])
  
  if (loading) {
    return (
      <LoadingSpinner>
        <FaSpinner size={40} />
      </LoadingSpinner>
    )
  }
  
  return (
    <div>
      <h1>Error Flags</h1>
      
      <ErrorsContainer>
        {errors.length === 0 ? (
          <NoErrorsMessage>
            No errors found. All systems are running smoothly!
          </NoErrorsMessage>
        ) : (
          errors.map(error => (
            <ErrorItem key={error.id}>
              <ErrorHeader>
                <ErrorTitle>
                  <FaExclamationTriangle />
                  {error.error_type}
                </ErrorTitle>
                <ErrorMeta>
                  {new Date(error.timestamp).toLocaleString()}
                </ErrorMeta>
              </ErrorHeader>
              
              <div>
                <strong>Model:</strong> {error.model_name}
              </div>
              <div>
                <strong>Attempt:</strong> {error.attempt}
              </div>
              
              <ErrorDetails>
                <div>
                  <strong>Requires Manual Review:</strong>{' '}
                  {error.requires_manual_review ? 'Yes' : 'No'}
                </div>
              </ErrorDetails>
            </ErrorItem>
          ))
        )}
      </ErrorsContainer>
    </div>
  )
}

export default ErrorFlags

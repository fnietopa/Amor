import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import styled from 'styled-components'
import { FaSpinner, FaSearch } from 'react-icons/fa'

const HistoryContainer = styled.div`
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-bottom: 20px;
`

const SearchBar = styled.div`
  display: flex;
  margin-bottom: 20px;
  
  input {
    flex: 1;
    padding: 10px;
    border: 1px solid var(--border-color);
    border-radius: 4px 0 0 4px;
    font-size: 1rem;
  }
  
  button {
    padding: 10px 15px;
    background-color: var(--primary-color);
    color: white;
    border: none;
    border-radius: 0 4px 4px 0;
    cursor: pointer;
    
    &:hover {
      background-color: #2980b9;
    }
  }
`

const QuestionTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  
  th, td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
  }
  
  th {
    background-color: #f8f9fa;
    font-weight: 600;
  }
  
  tr:hover {
    background-color: #f8f9fa;
  }
`

const QuestionLink = styled(Link)`
  color: var(--primary-color);
  text-decoration: none;
  
  &:hover {
    text-decoration: underline;
  }
`

const Pagination = styled.div`
  display: flex;
  justify-content: center;
  margin-top: 20px;
  gap: 10px;
`

const PageButton = styled.button`
  padding: 8px 12px;
  background-color: ${props => props.active ? 'var(--primary-color)' : 'white'};
  color: ${props => props.active ? 'white' : 'var(--text-color)'};
  border: 1px solid var(--border-color);
  border-radius: 4px;
  cursor: pointer;
  
  &:hover {
    background-color: ${props => props.active ? '#2980b9' : '#f8f9fa'};
  }
  
  &:disabled {
    background-color: #f8f9fa;
    color: #6c757d;
    cursor: not-allowed;
  }
`

const LoadingSpinner = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 50px;
  
  svg {
    animation: spin 1s linear infinite;
  }
  
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`

function History() {
  const [questions, setQuestions] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [questionsPerPage] = useState(10)
  
  useEffect(() => {
    const fetchQuestions = async () => {
      try {
        const response = await fetch('/api/questions')
        if (response.ok) {
          const data = await response.json()
          setQuestions(data)
        } else {
          console.error('Failed to fetch questions')
        }
      } catch (error) {
        console.error('Error fetching questions:', error)
      } finally {
        setLoading(false)
      }
    }
    
    fetchQuestions()
  }, [])
  
  // Filter questions based on search term
  const filteredQuestions = questions.filter(question =>
    question.text.toLowerCase().includes(searchTerm.toLowerCase())
  )
  
  // Pagination
  const indexOfLastQuestion = currentPage * questionsPerPage
  const indexOfFirstQuestion = indexOfLastQuestion - questionsPerPage
  const currentQuestions = filteredQuestions.slice(indexOfFirstQuestion, indexOfLastQuestion)
  const totalPages = Math.ceil(filteredQuestions.length / questionsPerPage)
  
  const paginate = (pageNumber) => setCurrentPage(pageNumber)
  
  if (loading) {
    return (
      <LoadingSpinner>
        <FaSpinner size={40} />
      </LoadingSpinner>
    )
  }
  
  return (
    <div>
      <h1>Question History</h1>
      
      <HistoryContainer>
        <SearchBar>
          <input
            type="text"
            placeholder="Search questions..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value)
              setCurrentPage(1) // Reset to first page on search
            }}
          />
          <button>
            <FaSearch />
          </button>
        </SearchBar>
        
        {currentQuestions.length === 0 ? (
          <p>No questions found.</p>
        ) : (
          <>
            <QuestionTable>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Question</th>
                  <th>Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentQuestions.map(question => (
                  <tr key={question.id}>
                    <td>{question.id}</td>
                    <td>
                      {question.text.length > 100
                        ? `${question.text.substring(0, 100)}...`
                        : question.text}
                    </td>
                    <td>{new Date(question.timestamp).toLocaleString()}</td>
                    <td>
                      <QuestionLink to={`/question/${question.id}`}>
                        View Details
                      </QuestionLink>
                    </td>
                  </tr>
                ))}
              </tbody>
            </QuestionTable>
            
            {totalPages > 1 && (
              <Pagination>
                <PageButton
                  onClick={() => paginate(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  Previous
                </PageButton>
                
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(number => (
                  <PageButton
                    key={number}
                    active={currentPage === number}
                    onClick={() => paginate(number)}
                  >
                    {number}
                  </PageButton>
                ))}
                
                <PageButton
                  onClick={() => paginate(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  Next
                </PageButton>
              </Pagination>
            )}
          </>
        )}
      </HistoryContainer>
    </div>
  )
}

export default History
